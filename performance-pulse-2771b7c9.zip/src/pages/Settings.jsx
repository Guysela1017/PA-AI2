import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import {
  Settings as SettingsIcon,
  User as UserIcon,
  Bell,
  Sun,
  Moon,
  Monitor,
  Clock,
  Calendar,
  Zap,
  Save,
  RefreshCw,
  Plus,
  X,
  CheckCircle,
  XCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function SettingsPage() {
  const [userData, setUserData] = useState({
    preferred_working_hours: {
      start: "09:00",
      end: "17:00"
    },
    focus_times: [],
    energy_pattern: "morning_person",
    theme: "system",
    notification_preferences: {
      task_reminders: true,
      daily_summary: true,
      performance_insights: true
    }
  });
  
  const [workStart, setWorkStart] = useState("09:00");
  const [workEnd, setWorkEnd] = useState("17:00");
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [userProfile, setUserProfile] = useState(null);
  const [currentTab, setCurrentTab] = useState("preferences");
  const [isMounted, setIsMounted] = useState(false);

  // For focus times
  const [newFocusTime, setNewFocusTime] = useState({
    start: "10:00",
    end: "12:00",
    days: ["monday", "tuesday", "wednesday", "thursday", "friday"]
  });
  const [showFocusTimeForm, setShowFocusTimeForm] = useState(false);

  useEffect(() => {
    loadUserData();
    setIsMounted(true);
  }, []);

  const loadUserData = async () => {
    try {
      const user = await User.me();
      setUserProfile(user);
      
      if (user.preferred_working_hours) {
        setUserData(user);
        setWorkStart(user.preferred_working_hours.start || "09:00");
        setWorkEnd(user.preferred_working_hours.end || "17:00");
      }
    } catch (error) {
      console.error("Error loading user data:", error);
    }
  };

  const handleSavePreferences = async () => {
    setIsSaving(true);
    try {
      // Update the working hours from the time picker values
      const dataToSave = {
        ...userData,
        preferred_working_hours: {
          start: workStart,
          end: workEnd
        }
      };
      
      await User.updateMyUserData(dataToSave);
      setSaveSuccess(true);
      
      // Reset success message after a delay
      setTimeout(() => {
        setSaveSuccess(false);
      }, 3000);
    } catch (error) {
      console.error("Error saving preferences:", error);
    }
    setIsSaving(false);
  };

  const handleEnergyPatternChange = (value) => {
    setUserData({
      ...userData,
      energy_pattern: value
    });
  };

  const handleThemeChange = (value) => {
    setUserData({
      ...userData,
      theme: value
    });
    
    // Apply the theme change immediately
    if (value === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      document.documentElement.classList.toggle("dark", systemTheme === "dark");
    } else {
      document.documentElement.classList.toggle("dark", value === "dark");
    }
  };

  const handleNotificationChange = (key, value) => {
    setUserData({
      ...userData,
      notification_preferences: {
        ...userData.notification_preferences,
        [key]: value
      }
    });
  };

  const handleAddFocusTime = () => {
    setUserData({
      ...userData,
      focus_times: [...(userData.focus_times || []), newFocusTime]
    });
    
    setNewFocusTime({
      start: "10:00",
      end: "12:00",
      days: ["monday", "tuesday", "wednesday", "thursday", "friday"]
    });
    
    setShowFocusTimeForm(false);
  };

  const handleRemoveFocusTime = (index) => {
    setUserData({
      ...userData,
      focus_times: userData.focus_times.filter((_, i) => i !== index)
    });
  };

  const handleDayToggle = (day) => {
    if (newFocusTime.days.includes(day)) {
      setNewFocusTime({
        ...newFocusTime,
        days: newFocusTime.days.filter(d => d !== day)
      });
    } else {
      setNewFocusTime({
        ...newFocusTime,
        days: [...newFocusTime.days, day]
      });
    }
  };

  const formatTimeRange = (startTime, endTime) => {
    try {
      const formattedStart = format(new Date(`2000-01-01T${startTime}`), "h:mm a");
      const formattedEnd = format(new Date(`2000-01-01T${endTime}`), "h:mm a");
      return `${formattedStart} - ${formattedEnd}`;
    } catch (error) {
      return `${startTime} - ${endTime}`;
    }
  };

  const formatDayList = (days) => {
    if (days.length === 7) return "Every day";
    if (days.length === 5 && 
        days.includes("monday") && 
        days.includes("tuesday") && 
        days.includes("wednesday") && 
        days.includes("thursday") && 
        days.includes("friday")) {
      return "Weekdays";
    }
    if (days.length === 2 && 
        days.includes("saturday") && 
        days.includes("sunday")) {
      return "Weekends";
    }
    
    return days.map(day => day.charAt(0).toUpperCase() + day.slice(1, 3)).join(", ");
  };

  return (
    <div className="container mx-auto py-6 px-4 max-w-5xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Settings</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Personalize your performance management experience
          </p>
        </div>
      </div>
      
      <Tabs 
        defaultValue="preferences" 
        value={currentTab}
        onValueChange={setCurrentTab}
        className="mb-6"
      >
        <TabsList className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 w-full mb-6">
          <TabsTrigger value="preferences" className="flex items-center">
            <SettingsIcon className="mr-2 h-4 w-4" />
            Preferences
          </TabsTrigger>
          <TabsTrigger value="schedule" className="flex items-center">
            <Clock className="mr-2 h-4 w-4" />
            Work Schedule
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center">
            <Bell className="mr-2 h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="account" className="flex items-center">
            <UserIcon className="mr-2 h-4 w-4" />
            Account
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="preferences">
          <Card>
            <CardHeader>
              <CardTitle>General Preferences</CardTitle>
              <CardDescription>
                Personalize your app settings and experience
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="theme" className="text-base flex items-center">
                    <Sun className="mr-2 h-4 w-4 text-orange-500" />
                    Theme Preference
                  </Label>
                  <div className="grid grid-cols-3 gap-4 mt-3">
                    <Button
                      type="button"
                      variant={userData.theme === "light" ? "default" : "outline"}
                      className={cn(
                        "flex flex-col items-center justify-center h-24 space-y-2",
                        userData.theme === "light" ? "border-blue-500" : ""
                      )}
                      onClick={() => handleThemeChange("light")}
                    >
                      <Sun className="h-6 w-6" />
                      <span>Light</span>
                    </Button>
                    <Button
                      type="button"
                      variant={userData.theme === "dark" ? "default" : "outline"}
                      className={cn(
                        "flex flex-col items-center justify-center h-24 space-y-2",
                        userData.theme === "dark" ? "border-blue-500" : ""
                      )}
                      onClick={() => handleThemeChange("dark")}
                    >
                      <Moon className="h-6 w-6" />
                      <span>Dark</span>
                    </Button>
                    <Button
                      type="button"
                      variant={userData.theme === "system" ? "default" : "outline"}
                      className={cn(
                        "flex flex-col items-center justify-center h-24 space-y-2",
                        userData.theme === "system" ? "border-blue-500" : ""
                      )}
                      onClick={() => handleThemeChange("system")}
                    >
                      <Monitor className="h-6 w-6" />
                      <span>System</span>
                    </Button>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Label htmlFor="energy_pattern" className="text-base flex items-center">
                    <Zap className="mr-2 h-4 w-4 text-yellow-500" />
                    Energy Pattern
                  </Label>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                    This helps us recommend optimal times for different task types
                  </p>
                  <Select
                    value={userData.energy_pattern}
                    onValueChange={handleEnergyPatternChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select energy pattern" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning_person">Morning Person (High energy early in the day)</SelectItem>
                      <SelectItem value="night_owl">Night Owl (Peak energy in the evening)</SelectItem>
                      <SelectItem value="afternoon_peak">Afternoon Peak (Most productive mid-day)</SelectItem>
                      <SelectItem value="consistent">Consistent Energy Throughout the Day</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex justify-end pt-4">
                <Button
                  type="button"
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={handleSavePreferences}
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" /> Save Preferences
                    </>
                  )}
                </Button>
              </div>
              
              {saveSuccess && (
                <div className="mt-2 p-2 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-md flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2" /> Settings saved successfully
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Work Schedule</CardTitle>
              <CardDescription>
                Define your preferred working hours and focus times
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-base flex items-center">
                  <Clock className="mr-2 h-4 w-4 text-blue-500" />
                  Preferred Working Hours
                </Label>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                  Set your typical working hours for scheduling tasks
                </p>
                <div className="flex flex-col sm:flex-row gap-4 items-end mb-6">
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="work_start">Start Time</Label>
                    <Input
                      id="work_start"
                      type="time"
                      value={workStart}
                      onChange={(e) => setWorkStart(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="work_end">End Time</Label>
                    <Input
                      id="work_end"
                      type="time"
                      value={workEnd}
                      onChange={(e) => setWorkEnd(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="pt-4">
                <div className="flex items-center justify-between mb-3">
                  <Label className="text-base flex items-center">
                    <Zap className="mr-2 h-4 w-4 text-yellow-500" />
                    Focus Time Blocks
                  </Label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowFocusTimeForm(true)}
                    className="flex items-center"
                  >
                    <Plus className="h-4 w-4 mr-1" /> Add Focus Time
                  </Button>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                  Define periods when you're most focused for important tasks
                </p>
                
                {showFocusTimeForm && (
                  <Card className="mb-4 p-4 border-dashed">
                    <div className="space-y-4">
                      <div className="flex flex-col sm:flex-row gap-4">
                        <div className="space-y-2 flex-1">
                          <Label>Start Time</Label>
                          <Input
                            type="time"
                            value={newFocusTime.start}
                            onChange={(e) => setNewFocusTime({...newFocusTime, start: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2 flex-1">
                          <Label>End Time</Label>
                          <Input
                            type="time"
                            value={newFocusTime.end}
                            onChange={(e) => setNewFocusTime({...newFocusTime, end: e.target.value})}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label className="mb-2 block">Days of Week</Label>
                        <div className="flex flex-wrap gap-2">
                          {["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"].map(day => (
                            <Badge
                              key={day}
                              variant={newFocusTime.days.includes(day) ? "default" : "outline"}
                              className="cursor-pointer"
                              onClick={() => handleDayToggle(day)}
                            >
                              {day.charAt(0).toUpperCase() + day.slice(1, 3)}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex justify-end gap-2 pt-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setShowFocusTimeForm(false)}
                        >
                          Cancel
                        </Button>
                        <Button 
                          size="sm"
                          onClick={handleAddFocusTime}
                          disabled={newFocusTime.days.length === 0}
                        >
                          Add
                        </Button>
                      </div>
                    </div>
                  </Card>
                )}
                
                <div className="space-y-3">
                  {userData.focus_times && userData.focus_times.length > 0 ? (
                    userData.focus_times.map((focusTime, index) => (
                      <div 
                        key={index} 
                        className="flex justify-between items-center p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800"
                      >
                        <div>
                          <p className="font-medium">
                            {formatTimeRange(focusTime.start, focusTime.end)}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {formatDayList(focusTime.days)}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveFocusTime(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                      <p>No focus times defined yet</p>
                      <p className="text-sm">Add focus time blocks to help optimize your schedule</p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex justify-end pt-4">
                <Button
                  type="button"
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={handleSavePreferences}
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" /> Save Schedule
                    </>
                  )}
                </Button>
              </div>
              
              {saveSuccess && (
                <div className="mt-2 p-2 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-md flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2" /> Schedule saved successfully
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>
                Manage how and when you receive updates and reminders
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Task Reminders</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Receive reminders for upcoming and due tasks
                    </p>
                  </div>
                  <Switch
                    checked={userData.notification_preferences?.task_reminders}
                    onCheckedChange={(checked) => handleNotificationChange("task_reminders", checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Daily Summary</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Get a daily summary of your completed and upcoming tasks
                    </p>
                  </div>
                  <Switch
                    checked={userData.notification_preferences?.daily_summary}
                    onCheckedChange={(checked) => handleNotificationChange("daily_summary", checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Performance Insights</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Receive weekly insights about your productivity trends
                    </p>
                  </div>
                  <Switch
                    checked={userData.notification_preferences?.performance_insights}
                    onCheckedChange={(checked) => handleNotificationChange("performance_insights", checked)}
                  />
                </div>
              </div>
              
              <div className="flex justify-end pt-4">
                <Button
                  type="button"
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={handleSavePreferences}
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" /> Save Preferences
                    </>
                  )}
                </Button>
              </div>
              
              {saveSuccess && (
                <div className="mt-2 p-2 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-md flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2" /> Settings saved successfully
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Account Information</CardTitle>
              <CardDescription>
                View and manage your account details
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {userProfile ? (
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 text-xl font-bold">
                      {userProfile.full_name ? userProfile.full_name.charAt(0).toUpperCase() : "U"}
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">{userProfile.full_name}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{userProfile.email}</p>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <h4 className="font-medium mb-2">Account Details</h4>
                    <div className="space-y-3">
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-sm text-gray-500 dark:text-gray-400">Name</div>
                        <div className="col-span-2">{userProfile.full_name}</div>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-sm text-gray-500 dark:text-gray-400">Email</div>
                        <div className="col-span-2">{userProfile.email}</div>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-sm text-gray-500 dark:text-gray-400">Role</div>
                        <div className="col-span-2 capitalize">{userProfile.role}</div>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-sm text-gray-500 dark:text-gray-400">Account Created</div>
                        <div className="col-span-2">
                          {userProfile.created_date ? format(new Date(userProfile.created_date), "MMMM d, yyyy") : "N/A"}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-8 text-center text-gray-500 dark:text-gray-400">
                  <UserIcon className="w-12 h-12 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
                  <p>User information is not available or you are not logged in.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}