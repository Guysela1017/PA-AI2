
import React, { useState, useEffect } from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameMonth, isSameDay, addDays } from "date-fns";
import { Task } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import DateNavigator from "../components/common/DateNavigator";
import TaskModal from "../components/task/TaskModal";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import TaskItem from "../components/task/TaskItem";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import DayPerformanceCell from "../components/monthly-view/DayPerformanceCell";
import DayDetails from "../components/monthly-view/DayDetails";
import { Performance } from "@/api/entities/performance";

export default function MonthlyView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [tasks, setTasks] = useState([]);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isDateSheetOpen, setIsDateSheetOpen] = useState(false);
  const [deleteAlert, setDeleteAlert] = useState({ show: false, taskId: null });
  const [loading, setLoading] = useState(true);
  const [performances, setPerformances] = useState([]);

  // Get days for the month view
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const startDate = monthStart;
  const endDate = monthEnd;
  
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  // Create a 7-column calendar grid
  const getDayGridItems = () => {
    // Start with weekday labels
    const weekdayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => ({
      date: null,
      isHeader: true,
      label: day
    }));
    
    // Adjust days to start on Monday (1) instead of Sunday (0)
    let dayOfWeekStart = getDay(startDate);
    // Convert Sunday (0) to 7 for our Monday-start grid
    dayOfWeekStart = dayOfWeekStart === 0 ? 7 : dayOfWeekStart;
    
    // Add empty cells for days before the start of the month
    const leadingEmptyCells = Array.from({ length: dayOfWeekStart - 1 }).map((_, i) => ({
      date: addDays(startDate, i - dayOfWeekStart + 1),
      isCurrentMonth: false,
      isEmpty: true
    }));
    
    // Add the actual days of the month
    const monthDays = days.map(day => ({
      date: day,
      isCurrentMonth: isSameMonth(day, currentDate),
      isToday: isSameDay(day, new Date())
    }));
    
    // Combine everything into a grid
    return [...weekdayLabels, ...leadingEmptyCells, ...monthDays];
  };
  
  const gridItems = getDayGridItems();

  useEffect(() => {
    loadTasks();
    loadPerformances();
  }, [currentDate]);

  const loadTasks = async () => {
    setLoading(true);
    try {
      const allTasks = await Task.list();
      setTasks(allTasks);
    } catch (error) {
      console.error("Error loading tasks:", error);
    }
    setLoading(false);
  };

  const loadPerformances = async () => {
    try {
      const startDateStr = format(startOfMonth(currentDate), "yyyy-MM-dd");
      const endDateStr = format(endOfMonth(currentDate), "yyyy-MM-dd");
  
      // Fetch performances within the current month
      const monthlyPerformances = await Performance.filter({
          date_gte: startDateStr,
          date_lte: endDateStr
      });
  
      setPerformances(monthlyPerformances);
    } catch (error) {
      console.error("Error loading performances:", error);
    }
  };

  const handleSaveTask = async (taskData) => {
    try {
      if (taskData.id) {
        await Task.update(taskData.id, taskData);
      } else {
        await Task.create(taskData);
      }
      
      setIsTaskModalOpen(false);
      setCurrentTask(null);
      loadTasks();
      loadPerformances();
    } catch (error) {
      console.error("Error saving task:", error);
    }
  };

  const handleTaskAction = async (action, task) => {
    try {
      switch (action) {
        case "toggle": {
          const isCompleted = !task.completed;
          const completionTime = isCompleted ? new Date().toISOString() : null;
          
          await Task.update(task.id, { 
            completed: isCompleted, 
            completed_at: completionTime 
          });
          
          // Update performance metrics if needed
          if (task.scheduled_date === format(new Date(), "yyyy-MM-dd")) {
            const performance = await Performance.filter({ date: task.scheduled_date });
            
            if (performance.length > 0) {
              const current = performance[0];
              await Performance.update(current.id, {
                tasks_completed: isCompleted 
                  ? current.tasks_completed + 1 
                  : current.tasks_completed - 1
              });
            }
          }
          break;
        }
          
        case "complete":
          const isCompleted = !task.completed;
          const completedAt = isCompleted ? new Date().toISOString() : null;
          
          await Task.update(task.id, { 
            completed: isCompleted, 
            completed_at: completedAt 
          });
          loadTasks();
          loadPerformances();
          break;
          
        case "edit":
          setCurrentTask(task);
          setIsTaskModalOpen(true);
          break;
          
        case "delete":
          setDeleteAlert({ show: true, taskId: task });
          break;
          
        case "duplicate":
          const { id, created_date, updated_date, completed, completed_at, ...taskToDuplicate } = task;
          setCurrentTask({
            ...taskToDuplicate,
            title: `Copy of ${taskToDuplicate.title}`
          });
          setIsTaskModalOpen(true);
          break;
          
        default:
          break;
      }
      
      loadTasks();
    } catch (error) {
      console.error("Error handling task action:", error);
    }
  };

  const confirmDeleteTask = async () => {
    if (deleteAlert.taskId) {
      await Task.delete(deleteAlert.taskId);
      setDeleteAlert({ show: false, taskId: null });
      loadTasks();
      loadPerformances();
    }
  };

  // Get tasks for a specific day
  const getTasksForDay = (date) => {
    if (!date) return [];
    const dateStr = format(date, "yyyy-MM-dd");
    return tasks.filter(task => task.scheduled_date === dateStr);
  };

  const handleDayClick = (date) => {
    if (!date || !isSameMonth(date, currentDate)) return;
    
    setSelectedDate(date);
    setIsDateSheetOpen(true);
  };

  const handleAddTaskForDay = (date) => {
    setCurrentTask({ 
      scheduled_date: format(date, "yyyy-MM-dd"),
      scheduled_time: "09:00"
    });
    setIsDateSheetOpen(false);
    setIsTaskModalOpen(true);
  };

  const priorityColors = {
    low: "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-800",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-800",
    high: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/20 dark:text-orange-300 dark:border-orange-800",
    urgent: "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-800"
  };

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Monthly View</h1>
          <p className="text-gray-500 dark:text-gray-400">
            See your month at a glance
          </p>
        </div>
        
        <div className="flex items-center mt-4 md:mt-0">
          <Button
            onClick={() => {
              setCurrentTask(null);
              setIsTaskModalOpen(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="mr-2 h-4 w-4" /> New Task
          </Button>
        </div>
      </div>
      
      <DateNavigator
        currentDate={currentDate}
        onDateChange={setCurrentDate}
        viewType="month"
        className="mb-6"
      />
      
      <Card>
        <CardHeader className="pb-0">
          <CardTitle className="text-lg font-medium">
            {format(currentDate, "MMMM yyyy")}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-1 mt-4 min-h-[600px]">
            {/* Weekday headers */}
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
              <div key={day} className="h-10 flex items-center justify-center">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  {day}
                </span>
              </div>
            ))}
            
            {/* Calendar days */}
            {gridItems.map((item, i) => {
              if (!item.date) return <div key={i} className="h-28 sm:h-36"></div>;
              
              const dayTasks = getTasksForDay(item.date);
              const dateStr = format(item.date, "yyyy-MM-dd");
              const dayPerformance = performances.find(p => p.date === dateStr);
              
              return (
                <DayPerformanceCell
                  key={i}
                  date={item.date}
                  isToday={item.isToday}
                  isCurrentMonth={item.isCurrentMonth}
                  tasks={dayTasks}
                  performance={dayPerformance}
                  onClick={() => handleDayClick(item.date)}
                />
              );
            })}
          </div>
        </CardContent>
      </Card>
      
      {/* Day Details Sheet */}
      <DayDetails
        isOpen={isDateSheetOpen}
        onClose={() => setIsDateSheetOpen(false)}
        date={selectedDate}
        tasks={getTasksForDay(selectedDate)}
        performance={performances.find(p => p.date === format(selectedDate, "yyyy-MM-dd"))}
        onAddTask={handleAddTaskForDay}
        onTaskAction={handleTaskAction}
      />
      
      {/* Task Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setCurrentTask(null);
        }}
        onSave={handleSaveTask}
        initialTask={currentTask}
      />
      
      {/* Delete Confirmation */}
      <AlertDialog 
        open={deleteAlert.show} 
        onOpenChange={(open) => !open && setDeleteAlert({ show: false, taskId: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this task and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTask}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
