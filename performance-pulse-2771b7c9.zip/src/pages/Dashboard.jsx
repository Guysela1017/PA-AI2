
import React, { useState, useEffect } from "react";
import { format, startOfToday, endOfToday, parseISO, isBefore, addMinutes, isSameDay } from "date-fns";
import { Task, Performance } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, CheckSquare, Clock, ListChecks, BarChart4, Sparkles, AlertCircle } from "lucide-react";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import TaskModal from "../components/task/TaskModal";
import TaskItem from "../components/task/TaskItem";
import HourlyTimeSlot from "../components/time-views/HourlyTimeSlot";
import PerformanceMetrics from "../components/common/PerformanceMetrics";
import DateNavigator from "../components/common/DateNavigator";
import { User } from "@/api/entities";
import { toast } from "@/components/ui/use-toast";

export default function Dashboard() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [tasks, setTasks] = useState([]);
  const [todaysTasks, setTodaysTasks] = useState([]);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [currentView, setCurrentView] = useState("schedule");
  const [deleteAlert, setDeleteAlert] = useState({ show: false, taskId: null });
  const [performance, setPerformance] = useState(null);
  const [loading, setLoading] = useState(true);

  // Add state for smart scheduling
  const [isAutoScheduling, setIsAutoScheduling] = useState(false);
  const [userPreferences, setUserPreferences] = useState(null);

  useEffect(() => {
    loadData();
    loadUserPreferences();
  }, [currentDate]);

  // Add function to load user preferences
  const loadUserPreferences = async () => {
    try {
      const userData = await User.me();
      setUserPreferences(userData);
    } catch (error) {
      console.error("Error loading user preferences:", error);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      // Load all tasks
      const allTasks = await Task.list();
      setTasks(allTasks);
      
      // Filter for today's tasks
      const today = format(currentDate, "yyyy-MM-dd");
      const filtered = allTasks.filter(task => 
        task.scheduled_date === today
      );
      setTodaysTasks(filtered);

      // Load or create performance data for today
      const performanceData = await Performance.filter({ date: today });
      
      if (performanceData.length > 0) {
        setPerformance(performanceData[0]);
      } else {
        // Create new performance record for today
        const newPerformance = {
          date: today,
          productivity_score: 0,
          tasks_completed: 0,
          tasks_planned: filtered.length,
          energy_level: 7,
          focus_score: 7,
          notes: ""
        };
        const created = await Performance.create(newPerformance);
        setPerformance(created);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };

  const handleSaveTask = async (taskData) => {
    try {
      // Handle auto-scheduling of tasks
      if (taskData.auto_schedule) {
        setIsAutoScheduling(true);
        
        // Find optimal time slot for this task
        const scheduledTask = await findOptimalTimeSlot(taskData);
        
        // If we found a good slot, use it; otherwise, keep the original date/time
        if (scheduledTask) {
          taskData.scheduled_time = scheduledTask.scheduled_time;
          
          // Show toast notification about the scheduled time
          toast({
            title: "Task Scheduled",
            description: `"${taskData.title}" scheduled for ${format(parseISO(`${taskData.scheduled_date}T${taskData.scheduled_time}`), "h:mm a")}`,
            variant: "default",
          });
        } else {
          // If no optimal time found, notify user
          toast({
            title: "Could not find an optimal time",
            description: "Using default time instead. You can reschedule manually.",
            variant: "destructive",
          });
        }
        
        setIsAutoScheduling(false);
      }

      if (taskData.id) {
        // Update existing task
        await Task.update(taskData.id, taskData);
      } else {
        // Create new task
        await Task.create(taskData);
      }
      
      setIsTaskModalOpen(false);
      setCurrentTask(null);
      
      // Update performance record if task is for today
      const today = format(currentDate, "yyyy-MM-dd");
      if (taskData.scheduled_date === today && performance) {
        const updatedTasksPlanned = performance.tasks_planned + 1;
        await Performance.update(performance.id, {
          tasks_planned: updatedTasksPlanned
        });
      }
      
      loadData();
    } catch (error) {
      console.error("Error saving task:", error);
    }
  };

  // Add function to find optimal time slot
  const findOptimalTimeSlot = async (taskData) => {
    try {
      // Get task date (use today if not specified)
      const taskDate = taskData.scheduled_date || format(new Date(), "yyyy-MM-dd");
      const taskDuration = taskData.duration || 30;
      
      // Get all tasks for the date
      const dateTasks = tasks.filter(task => task.scheduled_date === taskDate && task.scheduled_time);
      
      // Sort tasks by time
      dateTasks.sort((a, b) => {
        return a.scheduled_time.localeCompare(b.scheduled_time);
      });
      
      // Get user preferences or set defaults
      const workStartTime = userPreferences?.preferred_working_hours?.start || "09:00";
      const workEndTime = userPreferences?.preferred_working_hours?.end || "17:00";
      const energyPattern = userPreferences?.energy_pattern || "consistent";
      
      // Determine the best times based on energy requirements and work hours
      let preferredHours = [];
      if (taskData.energy_required === "high") {
        switch (energyPattern) {
          case "morning_person":
            preferredHours = [9, 10, 11];
            break;
          case "night_owl":
            preferredHours = [15, 16, 17];
            break;
          case "afternoon_peak":
            preferredHours = [13, 14, 15];
            break;
          default:
            preferredHours = [10, 11, 14, 15];
        }
      } else if (taskData.energy_required === "medium") {
        switch (energyPattern) {
          case "morning_person":
            preferredHours = [11, 12, 13, 14];
            break;
          case "night_owl":
            preferredHours = [13, 14, 15, 16];
            break;
          case "afternoon_peak":
            preferredHours = [12, 13, 16, 17];
            break;
          default:
            preferredHours = [9, 10, 13, 14, 15, 16];
        }
      } else {
        // Low energy tasks
        switch (energyPattern) {
          case "morning_person":
            preferredHours = [15, 16, 17];
            break;
          case "night_owl":
            preferredHours = [9, 10, 11];
            break;
          case "afternoon_peak":
            preferredHours = [9, 10, 17];
            break;
          default:
            preferredHours = [12, 13, 16, 17];
        }
      }
      
      // Get the working hour bounds
      const [startHour] = workStartTime.split(":").map(Number);
      const [endHour] = workEndTime.split(":").map(Number);
      
      // Filter preferred hours to be within working hours
      preferredHours = preferredHours.filter(hour => hour >= startHour && hour < endHour);
      
      // If no preferred hours within work hours, use all work hours
      if (preferredHours.length === 0) {
        for (let h = startHour; h < endHour; h++) {
          preferredHours.push(h);
        }
      }
      
      // Find available slots within preferred hours
      const now = new Date();
      const today = startOfToday();
      const isTaskForToday = isSameDay(parseISO(taskDate), today);
      
      // Start with the most preferred hours
      for (const hour of preferredHours) {
        // Try each 30-min slot in this hour
        for (const minute of [0, 30]) {
          const slotTime = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`;
          const slotDateTime = parseISO(`${taskDate}T${slotTime}`);
          
          // Skip past times if scheduling for today
          if (isTaskForToday && isBefore(slotDateTime, now)) {
            continue;
          }
          
          // Check if slot conflicts with any existing task
          const hasConflict = dateTasks.some(existingTask => {
            const existingStart = parseISO(`${taskDate}T${existingTask.scheduled_time}`);
            const existingEnd = addMinutes(existingStart, existingTask.duration || 30);
            
            const newStart = slotDateTime;
            const newEnd = addMinutes(newStart, taskDuration);
            
            return (
              (isBefore(newStart, existingEnd) && isBefore(existingStart, newEnd)) ||
              (isBefore(existingStart, newEnd) && isBefore(newStart, existingEnd))
            );
          });
          
          if (!hasConflict) {
            return {
              ...taskData,
              scheduled_time: slotTime
            };
          }
        }
      }
      
      // If no slots in preferred hours, try any available slot during work hours
      const workHours = [];
      for (let h = startHour; h < endHour; h++) {
        workHours.push(h);
      }
      
      // Exclude already checked preferred hours
      const remainingHours = workHours.filter(h => !preferredHours.includes(h));
      
      for (const hour of remainingHours) {
        for (const minute of [0, 30]) {
          const slotTime = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`;
          const slotDateTime = parseISO(`${taskDate}T${slotTime}`);
          
          if (isTaskForToday && isBefore(slotDateTime, now)) {
            continue;
          }
          
          const hasConflict = dateTasks.some(existingTask => {
            const existingStart = parseISO(`${taskDate}T${existingTask.scheduled_time}`);
            const existingEnd = addMinutes(existingStart, existingTask.duration || 30);
            
            const newStart = slotDateTime;
            const newEnd = addMinutes(newStart, taskDuration);
            
            return (
              (isBefore(newStart, existingEnd) && isBefore(existingStart, newEnd)) ||
              (isBefore(existingStart, newEnd) && isBefore(newStart, existingEnd))
            );
          });
          
          if (!hasConflict) {
            return {
              ...taskData,
              scheduled_time: slotTime
            };
          }
        }
      }
      
      // If still no slot found, add task to the first workday hour or current hour + 1 if today
      let defaultHour;
      if (isTaskForToday) {
        defaultHour = Math.max(now.getHours() + 1, startHour);
      } else {
        defaultHour = startHour;
      }
      
      defaultHour = Math.min(defaultHour, endHour - 1); // Ensure it's within work hours
      
      return {
        ...taskData,
        scheduled_time: `${defaultHour.toString().padStart(2, "0")}:00`
      };
    } catch (error) {
      console.error("Error finding optimal time slot:", error);
      return null;
    }
  };

  const handleTaskAction = async (action, task) => {
    switch (action) {
      case "complete":
        const isCompleted = !task.completed;
        const completedAt = isCompleted ? new Date().toISOString() : null;
        
        await Task.update(task.id, { 
          completed: isCompleted, 
          completed_at: completedAt 
        });
        
        // Update performance metrics if needed
        if (task.scheduled_date === format(currentDate, "yyyy-MM-dd") && performance) {
          const tasksCompleted = isCompleted
            ? performance.tasks_completed + 1
            : performance.tasks_completed - 1;
            
          const completionRate = (tasksCompleted / performance.tasks_planned) * 100;
          const newProductivityScore = Math.round(
            (completionRate * 0.6) + 
            (performance.energy_level * 5) + 
            (performance.focus_score * 5)
          );
          
          await Performance.update(performance.id, {
            tasks_completed: tasksCompleted,
            productivity_score: Math.min(newProductivityScore, 100)
          });
        }
        
        loadData();
        break;
        
      case "edit":
        setCurrentTask(task);
        setIsTaskModalOpen(true);
        break;
        
      case "delete":
        setDeleteAlert({ show: true, taskId: task });
        break;
        
      case "duplicate":
        const { id, created_date, updated_date, completed, completed_at, ...taskToDuplicate } = task;
        setCurrentTask({
          ...taskToDuplicate,
          title: `Copy of ${taskToDuplicate.title}`
        });
        setIsTaskModalOpen(true);
        break;
        
      default:
        break;
    }
  };

  const confirmDeleteTask = async () => {
    if (deleteAlert.taskId) {
      await Task.delete(deleteAlert.taskId);
      setDeleteAlert({ show: false, taskId: null });
      loadData();
    }
  };

  const handleDropTask = async (taskData, scheduledDate, scheduledTime) => {
    try {
      // If existing task, update it with new date/time
      if (taskData.id) {
        await Task.update(taskData.id, {
          scheduled_date: scheduledDate,
          scheduled_time: scheduledTime
        });
      }
      
      loadData();
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  // Group today's tasks by hour
  const tasksByHour = {};
  todaysTasks.forEach(task => {
    if (task.scheduled_time) {
      const hour = parseInt(task.scheduled_time.split(':')[0]);
      if (!tasksByHour[hour]) {
        tasksByHour[hour] = [];
      }
      tasksByHour[hour].push(task);
    }
  });

  const hoursToShow = Array.from({ length: 16 }, (_, i) => i + 7); // 7am to 10pm
  
  const defaultTask = {
    title: "",
    description: "",
    scheduled_date: format(currentDate, "yyyy-MM-dd"),
    scheduled_time: "09:00",
    duration: 30,
    energy_required: "medium",
    auto_schedule: true
  };

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Today's Schedule</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Plan and track your daily performance
          </p>
        </div>
        
        <div className="flex items-center mt-4 md:mt-0">
          <Button
            onClick={() => {
              setCurrentTask({
                ...defaultTask,
                auto_schedule: true // default to auto-schedule for new tasks
              });
              setIsTaskModalOpen(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="mr-2 h-4 w-4" /> New Task
          </Button>
        </div>
      </div>
      
      <DateNavigator
        currentDate={currentDate}
        onDateChange={setCurrentDate}
        viewType="day"
        className="mb-6"
      />
      
      {performance && (
        <PerformanceMetrics 
          performance={performance} 
          className="mb-6"
        />
      )}
      
      <Tabs 
        defaultValue="schedule" 
        value={currentView}
        onValueChange={setCurrentView}
        className="mb-6"
      >
        <TabsList>
          <TabsTrigger value="schedule" className="flex items-center">
            <Clock className="mr-2 h-4 w-4" />
            Schedule
          </TabsTrigger>
          <TabsTrigger value="tasks" className="flex items-center">
            <ListChecks className="mr-2 h-4 w-4" />
            Task List
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="schedule" className="mt-4">
          <Card>
            <CardHeader className="pb-0">
              <CardTitle className="text-lg font-medium flex items-center">
                <Clock className="mr-2 h-5 w-5 text-blue-500" />
                Daily Schedule
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-auto border rounded-md">
                <div className="min-w-[600px]">
                  {hoursToShow.map(hour => (
                    <HourlyTimeSlot
                      key={hour}
                      hour={hour}
                      date={currentDate}
                      tasks={tasksByHour[hour] || []}
                      onDropTask={handleDropTask}
                      onTaskAction={handleTaskAction}
                      isCurrentHour={new Date().getHours() === hour}
                      compactTasks={true}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="tasks" className="mt-4">
          <Card>
            <CardHeader className="pb-0">
              <CardTitle className="text-lg font-medium flex items-center">
                <CheckSquare className="mr-2 h-5 w-5 text-blue-500" />
                Tasks for {format(currentDate, "MMMM d, yyyy")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {todaysTasks.length === 0 ? (
                <Alert>
                  <AlertDescription>
                    No tasks scheduled for today. Add a new task to get started.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-3 mt-3">
                  {todaysTasks.map(task => (
                    <TaskItem
                      key={task.id}
                      task={task}
                      onComplete={(task) => handleTaskAction("complete", task)}
                      onEdit={(task) => handleTaskAction("edit", task)}
                      onDelete={(id) => handleTaskAction("delete", {id})}
                      onDuplicate={(task) => handleTaskAction("duplicate", task)}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Task Modal - pass userPreferences */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setCurrentTask(null);
        }}
        onSave={handleSaveTask}
        initialTask={currentTask}
        userPreferences={userPreferences}
      />
      
      {/* Delete Confirmation */}
      <AlertDialog 
        open={deleteAlert.show} 
        onOpenChange={(open) => !open && setDeleteAlert({ show: false, taskId: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this task and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTask}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
