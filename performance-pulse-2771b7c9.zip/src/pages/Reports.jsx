import React, { useState, useEffect } from "react";
import { format, subDays, startOfWeek, endOfWeek, eachDayOfInterval, differenceInDays } from "date-fns";
import { Task, Performance } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, PieChart, LineChart, ResponsiveContainer, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Pie, Cell, Line } from "recharts";
import {
  Calendar,
  BarChart3,
  PieChart as PieChartIcon,
  TrendingUp,
  Download,
  Tag,
  CheckCircle,
  Clock,
  Zap,
  Search,
  Filter
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function ReportsPage() {
  const [tasks, setTasks] = useState([]);
  const [performances, setPerformances] = useState([]);
  const [reportType, setReportType] = useState("daily");
  const [reportView, setReportView] = useState("productivity");
  const [dateRange, setDateRange] = useState("week");
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [streaks, setStreaks] = useState({
    currentStreak: 0,
    longestStreak: 0,
    perfectWeeks: 0,
    perfectMonths: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load all tasks
      const allTasks = await Task.list();
      setTasks(allTasks);
      
      // Load performance data
      const allPerformances = await Performance.list("-date");
      setPerformances(allPerformances);
      
      // Calculate streaks
      calculateStreaks(allPerformances);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };

  const calculateStreaks = (performances) => {
    // Sort performances by date
    const sortedPerformances = [...performances].sort((a, b) => 
      new Date(a.date) - new Date(b.date)
    );

    // Calculate current streak
    let currentStreak = 0;
    let longestStreak = 0;
    let perfectWeeks = 0;
    let perfectMonths = 0;

    // Process each day for streaks
    for (let i = sortedPerformances.length - 1; i >= 0; i--) {
      const performance = sortedPerformances[i];
      
      // Consider a day successful if productivity >= 80%
      const isSuccessful = performance.productivity_score >= 80;
      
      // If successful, increase streak
      if (isSuccessful) {
        currentStreak++;
      } else {
        // Break the streak
        break;
      }
    }

    // Calculate longest streak
    let tempStreak = 0;
    for (const performance of sortedPerformances) {
      if (performance.productivity_score >= 80) {
        tempStreak++;
        if (tempStreak > longestStreak) {
          longestStreak = tempStreak;
        }
      } else {
        tempStreak = 0;
      }
    }

    // Calculate perfect weeks and months
    const weekData = calculateWeeklyData(sortedPerformances);
    const monthData = calculateMonthlyData(sortedPerformances);

    // A perfect week is when every day in the week has productivity >= 80%
    perfectWeeks = weekData.filter(week => 
      week.days.every(day => day.productivity_score >= 80)
    ).length;

    // A perfect month is when productivity_score average for the month is >= 85%
    perfectMonths = monthData.filter(month => month.averageProductivity >= 85).length;

    setStreaks({
      currentStreak,
      longestStreak,
      perfectWeeks,
      perfectMonths
    });
  };

  // Calculate weekly data aggregation
  const calculateWeeklyData = (performances) => {
    if (!performances.length) return [];
    
    // Group performances by week
    const weekMap = new Map();
    
    performances.forEach(perf => {
      const perfDate = new Date(perf.date);
      const weekStart = format(startOfWeek(perfDate, { weekStartsOn: 1 }), "yyyy-MM-dd");
      
      if (!weekMap.has(weekStart)) {
        weekMap.set(weekStart, { 
          weekStart, 
          days: [] 
        });
      }
      
      weekMap.get(weekStart).days.push(perf);
    });
    
    return Array.from(weekMap.values());
  };
  
  // Calculate monthly data aggregation
  const calculateMonthlyData = (performances) => {
    if (!performances.length) return [];
    
    // Group performances by month
    const monthMap = new Map();
    
    performances.forEach(perf => {
      const month = format(new Date(perf.date), "yyyy-MM");
      
      if (!monthMap.has(month)) {
        monthMap.set(month, {
          month,
          days: [],
          totalProductivity: 0,
          count: 0
        });
      }
      
      const monthData = monthMap.get(month);
      monthData.days.push(perf);
      monthData.totalProductivity += perf.productivity_score || 0;
      monthData.count++;
    });
    
    // Calculate averages
    return Array.from(monthMap.values()).map(month => ({
      ...month,
      averageProductivity: month.count > 0 ? month.totalProductivity / month.count : 0
    }));
  };

  // Get date range based on selected option
  const getDateRange = () => {
    const today = new Date();
    
    switch (dateRange) {
      case "week":
        return {
          start: startOfWeek(today, { weekStartsOn: 1 }),
          end: endOfWeek(today, { weekStartsOn: 1 }),
          label: "Current Week"
        };
      case "2weeks":
        return {
          start: subDays(startOfWeek(today, { weekStartsOn: 1 }), 7),
          end: endOfWeek(today, { weekStartsOn: 1 }),
          label: "Last 2 Weeks"
        };
      case "month":
        return {
          start: subDays(today, 30),
          end: today,
          label: "Last 30 Days"
        };
      default:
        return {
          start: startOfWeek(today, { weekStartsOn: 1 }),
          end: endOfWeek(today, { weekStartsOn: 1 }),
          label: "Current Week"
        };
    }
  };

  // Filter data based on date range and category
  const getFilteredData = () => {
    const { start, end } = getDateRange();
    
    let filteredTasks = tasks.filter(task => {
      const taskDate = new Date(task.scheduled_date);
      return taskDate >= start && taskDate <= end;
    });
    
    if (categoryFilter !== "all") {
      filteredTasks = filteredTasks.filter(task => task.category === categoryFilter);
    }
    
    const filteredPerformances = performances.filter(perf => {
      const perfDate = new Date(perf.date);
      return perfDate >= start && perfDate <= end;
    });
    
    return { filteredTasks, filteredPerformances };
  };

  // Prepare data for daily report
  const prepareDailyData = () => {
    const { start, end } = getDateRange();
    const days = eachDayOfInterval({ start, end });
    const { filteredTasks, filteredPerformances } = getFilteredData();
    
    return days.map(day => {
      const dateStr = format(day, "yyyy-MM-dd");
      const dayTasks = filteredTasks.filter(task => task.scheduled_date === dateStr);
      const dayPerformance = filteredPerformances.find(perf => perf.date === dateStr) || {
        productivity_score: 0,
        energy_level: 0,
        focus_score: 0,
        tasks_completed: 0,
        tasks_planned: 0
      };
      
      const completedTasks = dayTasks.filter(task => task.completed).length;
      const totalTasks = dayTasks.length;
      const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
      
      return {
        date: format(day, "MMM d"),
        fullDate: dateStr,
        tasks: totalTasks,
        completedTasks,
        completionRate,
        productivity: dayPerformance.productivity_score || 0,
        energy: dayPerformance.energy_level || 0,
        focus: dayPerformance.focus_score || 0
      };
    });
  };

  // Prepare data for category distribution
  const prepareCategoryData = () => {
    const { filteredTasks } = getFilteredData();
    
    const categoryCount = {};
    filteredTasks.forEach(task => {
      categoryCount[task.category] = (categoryCount[task.category] || 0) + 1;
    });
    
    return Object.entries(categoryCount).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1).replace(/_/g, ' '),
      value
    }));
  };

  // Prepare data for priority distribution
  const preparePriorityData = () => {
    const { filteredTasks } = getFilteredData();
    
    const priorityCount = {};
    filteredTasks.forEach(task => {
      priorityCount[task.priority] = (priorityCount[task.priority] || 0) + 1;
    });
    
    return Object.entries(priorityCount).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value
    }));
  };

  // Prepare data for energy vs productivity
  const prepareEnergyVsProductivityData = () => {
    const { filteredPerformances } = getFilteredData();
    
    return filteredPerformances.map(perf => ({
      date: format(new Date(perf.date), "MMM d"),
      energy: perf.energy_level || 0,
      productivity: perf.productivity_score || 0,
      focus: perf.focus_score || 0
    }));
  };

  // Prepare streak data for visualization
  const prepareStreakData = () => {
    return [
      {
        name: 'Current Streak',
        value: streaks.currentStreak,
        color: '#3b82f6'
      },
      {
        name: 'Longest Streak',
        value: streaks.longestStreak,
        color: '#10b981'
      },
      {
        name: 'Perfect Weeks',
        value: streaks.perfectWeeks,
        color: '#8b5cf6'
      },
      {
        name: 'Perfect Months',
        value: streaks.perfectMonths,
        color: '#f59e0b'
      }
    ];
  };

  const dailyData = prepareDailyData();
  const categoryData = prepareCategoryData();
  const priorityData = preparePriorityData();
  const energyVsProductivityData = prepareEnergyVsProductivityData();
  const streakData = prepareStreakData();

  const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899', '#6366f1'];
  
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-md shadow-lg">
          <p className="font-medium">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {entry.value.toFixed(entry.name === "completionRate" ? 1 : 0)}
              {entry.name === "completionRate" ? "%" : ""}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };
  
  const handleExportData = () => {
    try {
      const { label } = getDateRange();
      const reportData = dailyData.map(day => ({
        Date: day.fullDate,
        "Total Tasks": day.tasks,
        "Completed Tasks": day.completedTasks,
        "Completion Rate (%)": day.completionRate.toFixed(1),
        "Productivity Score": day.productivity,
        "Energy Level": day.energy,
        "Focus Score": day.focus
      }));
      
      // Convert to CSV
      const headers = Object.keys(reportData[0]);
      const csvContent = [
        headers.join(','),
        ...reportData.map(row => headers.map(header => JSON.stringify(row[header])).join(','))
      ].join('\n');
      
      // Create and download file
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `performance_report_${label.replace(/\s+/g, '_')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error exporting data:", error);
    }
  };

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Performance Reports</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Analyze your productivity and performance trends
          </p>
        </div>
        
        <div className="flex items-center mt-4 md:mt-0">
          <Button
            onClick={handleExportData}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Download className="mr-2 h-4 w-4" /> Export Data
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium flex items-center">
                <Calendar className="mr-2 h-4 w-4 text-blue-500" />
                Date Range
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger>
                <SelectValue placeholder="Select date range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Current Week</SelectItem>
                <SelectItem value="2weeks">Last 2 Weeks</SelectItem>
                <SelectItem value="month">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Tag className="mr-2 h-4 w-4 text-blue-500" />
              Category Filter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="work">Work</SelectItem>
                <SelectItem value="personal">Personal</SelectItem>
                <SelectItem value="health">Health</SelectItem>
                <SelectItem value="learning">Learning</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
              Task Completion
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {dailyData.reduce((sum, day) => sum + day.completedTasks, 0)} / {dailyData.reduce((sum, day) => sum + day.tasks, 0)}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {getDateRange().label}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Zap className="mr-2 h-4 w-4 text-yellow-500" />
              Avg. Productivity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(
                dailyData.reduce((sum, day) => sum + day.productivity, 0) / 
                (dailyData.filter(day => day.productivity > 0).length || 1)
              )}%
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {getDateRange().label}
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Performance Streaks Section */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="mr-2 h-5 w-5 text-blue-500" />
            Performance Streaks
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {streakData.map((item) => (
              <div key={item.name} className="flex flex-col items-center justify-center p-4 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                <div className="text-3xl font-bold" style={{ color: item.color }}>
                  {item.value}{item.name.includes('Streak') ? ' days' : ''}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400 text-center mt-1">
                  {item.name}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="productivity" value={reportView} onValueChange={setReportView} className="mb-6">
        <TabsList className="grid grid-cols-1 md:grid-cols-3 w-full mb-6">
          <TabsTrigger value="productivity" className="flex items-center">
            <BarChart3 className="mr-2 h-4 w-4" />
            Productivity Trends
          </TabsTrigger>
          <TabsTrigger value="distribution" className="flex items-center">
            <PieChartIcon className="mr-2 h-4 w-4" />
            Task Distribution
          </TabsTrigger>
          <TabsTrigger value="correlation" className="flex items-center">
            <TrendingUp className="mr-2 h-4 w-4" />
            Energy & Focus Correlation
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="productivity">
          <Card>
            <CardHeader>
              <CardTitle>Productivity & Task Completion</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyData} margin={{ top: 20, right: 30, left: 20, bottom: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="left" orientation="left" />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 100]} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar yAxisId="left" dataKey="tasks" name="Total Tasks" fill="#3b82f6" />
                    <Bar yAxisId="left" dataKey="completedTasks" name="Completed Tasks" fill="#10b981" />
                    <Line yAxisId="right" type="monotone" dataKey="completionRate" name="Completion Rate" stroke="#f59e0b" strokeWidth={2} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="distribution">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Tasks by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Tasks by Priority</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={priorityData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {priorityData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="correlation">
          <Card>
            <CardHeader>
              <CardTitle>Energy, Focus & Productivity Correlation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={energyVsProductivityData} margin={{ top: 20, right: 30, left: 20, bottom: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="left" orientation="left" domain={[0, 10]} />
                    <YAxis yAxis="right" orientation="right" domain={[0, 100]} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="energy" name="Energy Level" stroke="#f59e0b" strokeWidth={2} />
                    <Line yAxisId="left" type="monotone" dataKey="focus" name="Focus Score" stroke="#8b5cf6" strokeWidth={2} />
                    <Line yAxisId="right" type="monotone" dataKey="productivity" name="Productivity" stroke="#10b981" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Performance Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dailyData.length > 0 && (
              <>
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2">Productivity Patterns</h3>
                  <p>
                    {dailyData.reduce((sum, day) => sum + day.productivity, 0) > 0
                      ? `Your average productivity score is ${Math.round(
                          dailyData.reduce((sum, day) => sum + day.productivity, 0) / 
                          (dailyData.filter(day => day.productivity > 0).length || 1)
                        )}%. ${
                          Math.round(
                            dailyData.reduce((sum, day) => sum + day.productivity, 0) / 
                            (dailyData.filter(day => day.productivity > 0).length || 1)
                          ) > 75
                            ? "You're consistently performing well!"
                            : "There's room for improvement in your overall productivity."
                        }`
                      : "Not enough productivity data has been collected yet."}
                  </p>
                </div>
                
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2">Task Completion</h3>
                  <p>
                    {dailyData.reduce((sum, day) => sum + day.tasks, 0) > 0
                      ? `You've completed ${dailyData.reduce((sum, day) => sum + day.completedTasks, 0)} out of ${dailyData.reduce((sum, day) => sum + day.tasks, 0)} tasks (${Math.round(
                          (dailyData.reduce((sum, day) => sum + day.completedTasks, 0) / 
                          dailyData.reduce((sum, day) => sum + day.tasks, 0)) * 100
                        )}%). ${
                          (dailyData.reduce((sum, day) => sum + day.completedTasks, 0) / 
                          dailyData.reduce((sum, day) => sum + day.tasks, 0)) > 0.7
                            ? "Great job staying on top of your tasks!"
                            : "Consider focusing on completing more of your scheduled tasks."
                        }`
                      : "No tasks have been scheduled yet."}
                  </p>
                </div>
                
                <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2">Performance Streaks</h3>
                  <p>
                    {streaks.currentStreak > 0
                      ? `You're on a ${streaks.currentStreak}-day productivity streak! ${
                          streaks.currentStreak >= streaks.longestStreak
                            ? "This is your best streak so far!"
                            : `Your longest streak is ${streaks.longestStreak} days.`
                        }`
                      : "You don't have an active streak right now. Complete today's tasks to start a new streak!"}
                    {streaks.perfectWeeks > 0 &&
                      ` You've had ${streaks.perfectWeeks} perfect ${streaks.perfectWeeks === 1 ? 'week' : 'weeks'} with excellent productivity.`}
                  </p>
                </div>
                
                {categoryData.length > 0 && (
                  <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <h3 className="text-lg font-semibold mb-2">Category Distribution</h3>
                    <p>
                      Your most frequent task category is {categoryData.sort((a, b) => b.value - a.value)[0].name} 
                      ({Math.round((categoryData.sort((a, b) => b.value - a.value)[0].value / 
                        categoryData.reduce((sum, cat) => sum + cat.value, 0)) * 100)}% of all tasks).
                      {categoryData.length > 1
                        ? ` This is followed by ${categoryData.sort((a, b) => b.value - a.value)[1].name} 
                          (${Math.round((categoryData.sort((a, b) => b.value - a.value)[1].value / 
                          categoryData.reduce((sum, cat) => sum + cat.value, 0)) * 100)}%).`
                        : ""}
                    </p>
                  </div>
                )}
                
                {energyVsProductivityData.length > 0 && (
                  <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <h3 className="text-lg font-semibold mb-2">Energy & Focus Impact</h3>
                    <p>
                      {energyVsProductivityData.length > 1
                        ? `When your energy level is high, your productivity tends to ${
                            energyVsProductivityData.reduce((sum, day) => 
                              sum + (day.energy > 7 ? (day.productivity > 70 ? 1 : -1) : 0), 0) > 0
                              ? "increase"
                              : "not necessarily increase"
                          }. Focus appears to ${
                            energyVsProductivityData.reduce((sum, day) => 
                              sum + (day.focus > 7 ? (day.productivity > 70 ? 1 : -1) : 0), 0) > 0
                              ? "be strongly correlated with"
                              : "have less impact on"
                          } your overall productivity.`
                        : "More data is needed to analyze the relationship between energy, focus, and productivity."}
                    </p>
                  </div>
                )}
              </>
            )}
            
            {dailyData.length === 0 && (
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg text-center">
                <p className="text-gray-500 dark:text-gray-400">
                  No performance data available for the selected period. Start tracking your tasks and productivity to see insights.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}