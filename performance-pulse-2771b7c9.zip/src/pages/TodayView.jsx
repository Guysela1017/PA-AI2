
import React, { useState, useEffect } from "react";
import { format, parseISO, isToday, isPast } from "date-fns";
import { Task, Performance } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { Plus, Calendar, List, ListChecks, Clock, LayoutDashboard } from "lucide-react";

// Import our custom components
import CompletionSpeedometer from "../components/dashboard/CompletionSpeedometer";
import TodayTaskList from "../components/dashboard/TodayTaskList";
import RescheduleTaskDialog from "../components/dashboard/RescheduleTaskDialog";
import TaskModal from "../components/task/TaskModal";

export default function TodayView() {
  const navigate = useNavigate();
  const [currentTab, setCurrentTab] = useState("overview");
  const [tasks, setTasks] = useState([]);
  const [todaysTasks, setTodaysTasks] = useState([]);
  const [completedTasks, setCompletedTasks] = useState([]);
  const [missedTasks, setMissedTasks] = useState([]);
  const [performance, setPerformance] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [isRescheduleModalOpen, setIsRescheduleModalOpen] = useState(false);
  const [deleteTaskAlert, setDeleteTaskAlert] = useState({ open: false, task: null });
  
  // Today's date formatted as YYYY-MM-DD
  const today = format(new Date(), "yyyy-MM-dd");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load all tasks
      const allTasks = await Task.list();
      setTasks(allTasks);
      
      // Filter for today's tasks
      const tasksToday = allTasks.filter(task => task.scheduled_date === today);
      setTodaysTasks(tasksToday);
      
      // Filter for completed tasks today
      const completed = tasksToday.filter(task => task.completed);
      setCompletedTasks(completed);
      
      // Filter for missed tasks
      const missed = tasksToday.filter(task => task.status === 'missed');
      setMissedTasks(missed);

      // Load or create performance data for today
      const performanceData = await Performance.filter({ date: today });
      
      if (performanceData.length > 0) {
        setPerformance(performanceData[0]);
      } else {
        // Create new performance record for today
        const newPerformance = {
          date: today,
          productivity_score: 0,
          tasks_completed: completed.length,
          tasks_planned: tasksToday.length,
          energy_level: 7, // Default values
          focus_score: 7,
          notes: ""
        };
        const created = await Performance.create(newPerformance);
        setPerformance(created);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };
  
  // Calculate completion percentage for the speedometer
  const calculateCompletionPercentage = () => {
    if (todaysTasks.length === 0) return 0;
    return Math.round((completedTasks.length / todaysTasks.length) * 100);
  };

  // Handle various task actions
  const handleTaskAction = async (action, task) => {
    try {
      switch (action) {
        case 'complete':
          // Toggle completion
          const isCompleted = !task.completed;
          const completedAt = isCompleted ? new Date().toISOString() : null;
          
          await Task.update(task.id, { 
            completed: isCompleted, 
            completed_at: completedAt,
            status: isCompleted ? 'completed' : null
          });
          
          // Update performance metrics
          if (performance) {
            const tasksCompleted = isCompleted
              ? performance.tasks_completed + 1
              : performance.tasks_completed - 1;
              
            const completionRate = (tasksCompleted / performance.tasks_planned) * 100;
            const newProductivityScore = Math.round(
              (completionRate * 0.6) + 
              (performance.energy_level * 5) + 
              (performance.focus_score * 5)
            );
            
            await Performance.update(performance.id, {
              tasks_completed: Math.max(0, tasksCompleted),
              productivity_score: Math.min(100, newProductivityScore)
            });
          }
          
          break;
          
        case 'uncomplete':
          // Mark as incomplete
          await Task.update(task.id, { 
            completed: false, 
            completed_at: null,
            status: null
          });
          
          // Update performance metrics
          if (performance) {
            const tasksCompleted = performance.tasks_completed - 1;
            const completionRate = (tasksCompleted / performance.tasks_planned) * 100;
            const newProductivityScore = Math.round(
              (completionRate * 0.6) + 
              (performance.energy_level * 5) + 
              (performance.focus_score * 5)
            );
            
            await Performance.update(performance.id, {
              tasks_completed: Math.max(0, tasksCompleted),
              productivity_score: Math.min(100, Math.max(0, newProductivityScore))
            });
          }
          
          break;
          
        case 'edit':
          setCurrentTask(task);
          setIsTaskModalOpen(true);
          break;
          
        case 'reschedule':
          setCurrentTask(task);
          setIsRescheduleModalOpen(true);
          break;
          
        case 'mark-missed':
          await Task.update(task.id, { 
            status: 'missed',
            completed: false,
            completed_at: null
          });
          break;
          
        case 'delete':
          setDeleteTaskAlert({ open: true, task });
          break;
          
        case 'new':
          setCurrentTask({
            scheduled_date: today,
            scheduled_time: format(new Date(), 'HH:mm')
          });
          setIsTaskModalOpen(true);
          break;
          
        default:
          console.warn('Unknown task action:', action);
      }
      
      // Reload data
      loadData();
    } catch (error) {
      console.error(`Error handling task action ${action}:`, error);
    }
  };

  // Handle task save (new or edit)
  const handleSaveTask = async (taskData) => {
    try {
      if (taskData.id) {
        // Update existing task
        await Task.update(taskData.id, taskData);
      } else {
        // Create new task
        const newTask = await Task.create(taskData);
        
        // Update performance record with additional planned task
        if (taskData.scheduled_date === today && performance) {
          const updatedTasksPlanned = performance.tasks_planned + 1;
          await Performance.update(performance.id, {
            tasks_planned: updatedTasksPlanned
          });
        }
      }
      
      setIsTaskModalOpen(false);
      setCurrentTask(null);
      loadData();
    } catch (error) {
      console.error("Error saving task:", error);
    }
  };

  // Handle task rescheduling
  const handleRescheduleTask = async (task) => {
    try {
      await Task.update(task.id, task);
      setIsRescheduleModalOpen(false);
      loadData();
    } catch (error) {
      console.error("Error rescheduling task:", error);
    }
  };

  // Handle task deletion
  const handleDeleteTask = async () => {
    if (!deleteTaskAlert.task) return;
    
    try {
      await Task.delete(deleteTaskAlert.task.id);
      
      // Update performance metrics if needed
      if (deleteTaskAlert.task.scheduled_date === today && performance) {
        let tasksPlanned = performance.tasks_planned - 1;
        let tasksCompleted = performance.tasks_completed;
        
        // If the deleted task was completed, decrease completed count too
        if (deleteTaskAlert.task.completed) {
          tasksCompleted -= 1;
        }
        
        // Update performance record
        await Performance.update(performance.id, {
          tasks_planned: Math.max(0, tasksPlanned),
          tasks_completed: Math.max(0, tasksCompleted)
        });
      }
      
      setDeleteTaskAlert({ open: false, task: null });
      loadData();
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  // Navigate to tasks page
  const navigateToTasks = () => {
    navigate(createPageUrl("Tasks"));
  };

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Today's Overview</h1>
          <p className="text-gray-500 dark:text-gray-400">
            {format(new Date(), "EEEE, MMMM d, yyyy")}
          </p>
        </div>
        
        <div className="flex items-center mt-4 md:mt-0">
          <Button
            onClick={() => handleTaskAction('new', {})}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="mr-2 h-4 w-4" /> New Task
          </Button>
        </div>
      </div>
      
      <Tabs 
        defaultValue="overview" 
        value={currentTab}
        onValueChange={setCurrentTab}
        className="mb-6"
      >
        <TabsList>
          <TabsTrigger value="overview" className="flex items-center">
            <LayoutDashboard className="mr-2 h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="tasks" className="flex items-center">
            <ListChecks className="mr-2 h-4 w-4" />
            Tasks
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left column - Speedometer widget */}
            <Card className="lg:col-span-1">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Daily Progress</h3>
                <CompletionSpeedometer 
                  percentComplete={calculateCompletionPercentage()}
                  totalTasks={todaysTasks.length}
                  completedTasks={completedTasks.length}
                  missedTasks={missedTasks.length}
                />
              </CardContent>
            </Card>
            
            {/* Right column - Tasks list */}
            <Card className="lg:col-span-2">
              <CardContent className="p-6">
                <TodayTaskList 
                  tasks={todaysTasks}
                  isLoading={loading}
                  onTaskAction={handleTaskAction}
                  onViewAllClick={navigateToTasks}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="tasks" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <TodayTaskList 
                tasks={todaysTasks}
                isLoading={loading}
                onTaskAction={handleTaskAction}
                onViewAllClick={navigateToTasks}
                className="mb-0"
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Task Modal for creating/editing tasks */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setCurrentTask(null);
        }}
        onSave={handleSaveTask}
        initialTask={currentTask}
      />
      
      {/* Reschedule Dialog */}
      <RescheduleTaskDialog
        isOpen={isRescheduleModalOpen}
        onClose={() => {
          setIsRescheduleModalOpen(false);
          setCurrentTask(null);
        }}
        onReschedule={handleRescheduleTask}
        task={currentTask}
      />
      
      {/* Delete Confirmation */}
      <AlertDialog 
        open={deleteTaskAlert.open} 
        onOpenChange={(open) => !open && setDeleteTaskAlert({ open: false, task: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this task and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTask}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
