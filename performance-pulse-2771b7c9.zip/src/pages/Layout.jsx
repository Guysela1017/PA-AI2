

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { Task } from "@/api/entities";
import {
  LayoutDashboard,
  Calendar,
  CheckSquare,
  BarChart3,
  Settings,
  Menu,
  X,
  Sun,
  Moon,
  Monitor
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import NotificationManager from "./components/notifications/NotificationManager";

export default function Layout({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userPreferences, setUserPreferences] = useState({ theme: "system" });
  const [currentTheme, setCurrentTheme] = useState("light");
  const location = useLocation();

  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    // Fetch user preferences
    const loadUserPreferences = async () => {
      try {
        const userData = await User.me();
        setUserPreferences(userData);
        
        // Set initial theme
        const savedTheme = userData.theme || "system";
        if (savedTheme === "system") {
          const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
          setCurrentTheme(systemTheme);
        } else {
          setCurrentTheme(savedTheme);
        }
      } catch (error) {
        console.log("User not authenticated or preferences not set");
      }
    };
    
    // Load tasks for notifications
    const loadTasks = async () => {
      try {
        const allTasks = await Task.list();
        setTasks(allTasks);
      } catch (error) {
        console.error("Error loading tasks:", error);
      }
    };

    loadUserPreferences();
    loadTasks();
  }, []);
  
  // Apply theme changes
  useEffect(() => {
    if (currentTheme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [currentTheme]);

  const navigation = [
    { name: "Today", icon: LayoutDashboard, href: createPageUrl("Dashboard") },
    { name: "3-Day View", icon: Calendar, href: createPageUrl("ThreeDayView") },
    { name: "Weekly", icon: Calendar, href: createPageUrl("WeeklyView") },
    { name: "Monthly", icon: Calendar, href: createPageUrl("MonthlyView") },
    { name: "Tasks", icon: CheckSquare, href: createPageUrl("Tasks") },
    { name: "Reports", icon: BarChart3, href: createPageUrl("Reports") },
    { name: "Settings", icon: Settings, href: createPageUrl("Settings") }
  ];

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <div className="h-screen flex dark:bg-gray-900">
      <NotificationManager 
        tasks={tasks}
        preferences={userPreferences}
      />
      <style jsx="true">{`
        :root {
          --background: #ffffff;
          --foreground: #09090b;
          --card: #ffffff;
          --card-foreground: #09090b;
          --popover: #ffffff;
          --popover-foreground: #09090b;
          --primary: #3b82f6;
          --primary-foreground: #ffffff;
          --secondary: #f3f4f6;
          --secondary-foreground: #1f2937;
          --muted: #f3f4f6;
          --muted-foreground: #6b7280;
          --accent: #f3f4f6;
          --accent-foreground: #1f2937;
          --destructive: #ef4444;
          --destructive-foreground: #ffffff;
          --border: #e5e7eb;
          --input: #e5e7eb;
          --ring: #3b82f6;
          --radius: 0.5rem;
        }

        .dark {
          --background: #09090b;
          --foreground: #f9fafb;
          --card: #111827;
          --card-foreground: #f9fafb;
          --popover: #111827;
          --popover-foreground: #f9fafb;
          --primary: #3b82f6;
          --primary-foreground: #ffffff;
          --secondary: #1f2937;
          --secondary-foreground: #f9fafb;
          --muted: #1f2937;
          --muted-foreground: #9ca3af;
          --accent: #1f2937;
          --accent-foreground: #f9fafb;
          --destructive: #ef4444;
          --destructive-foreground: #f9fafb;
          --border: #1f2937;
          --input: #1f2937;
          --ring: #3b82f6;
        }
      `}</style>

      {/* Sidebar for desktop */}
      <div className="hidden md:flex md:flex-col md:w-64 md:fixed md:inset-y-0 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700">
        <div className="flex-1 flex flex-col min-h-0">
          <div className="flex items-center h-16 px-4 border-b border-gray-200 dark:border-gray-700">
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Performance Manager</h1>
          </div>
          <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <nav className="flex-1 px-2 space-y-1">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={cn(
                    isActive(item.href)
                      ? "bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white",
                    "group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors"
                  )}
                >
                  <item.icon
                    className={cn(
                      isActive(item.href)
                        ? "text-blue-600 dark:text-blue-400"
                        : "text-gray-400 group-hover:text-gray-500 dark:text-gray-500 dark:group-hover:text-gray-300",
                      "mr-3 flex-shrink-0 h-5 w-5 transition-colors"
                    )}
                    aria-hidden="true"
                  />
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex-shrink-0 flex border-t border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center">
              <div className="flex-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const newTheme = currentTheme === "light" ? "dark" : "light";
                    setCurrentTheme(newTheme);
                    
                    // Update user preferences if logged in
                    try {
                      User.updateMyUserData({ theme: newTheme });
                    } catch (error) {
                      console.log("Not logged in, theme not saved");
                    }
                  }}
                  className="mr-2"
                >
                  {currentTheme === "light" ? (
                    <Moon className="h-5 w-5" />
                  ) : (
                    <Sun className="h-5 w-5" />
                  )}
                </Button>
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
                    setCurrentTheme(systemTheme);
                    
                    // Update user preferences if logged in
                    try {
                      User.updateMyUserData({ theme: "system" });
                    } catch (error) {
                      console.log("Not logged in, theme not saved");
                    }
                  }}
                >
                  <Monitor className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className="md:hidden fixed inset-0 flex z-40 lg:hidden" role="dialog" aria-modal="true" 
           style={{ display: sidebarOpen ? 'flex' : 'none' }}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" aria-hidden="true" 
             onClick={() => setSidebarOpen(false)}></div>
        
        <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white dark:bg-gray-900">
          <div className="absolute top-0 right-0 -mr-12 pt-2">
            <button
              type="button"
              className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              onClick={() => setSidebarOpen(false)}
            >
              <span className="sr-only">Close sidebar</span>
              <X className="h-6 w-6 text-white" aria-hidden="true" />
            </button>
          </div>
          
          <div className="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
            <div className="flex-shrink-0 flex items-center px-4">
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Performance Manager</h1>
            </div>
            <nav className="mt-5 px-2 space-y-1">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={cn(
                    isActive(item.href)
                      ? "bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white",
                    "group flex items-center px-2 py-2 text-base font-medium rounded-md"
                  )}
                  onClick={() => setSidebarOpen(false)}
                >
                  <item.icon
                    className={cn(
                      isActive(item.href)
                        ? "text-blue-600 dark:text-blue-400"
                        : "text-gray-400 group-hover:text-gray-500 dark:text-gray-500 dark:group-hover:text-gray-300",
                      "mr-4 flex-shrink-0 h-6 w-6"
                    )}
                    aria-hidden="true"
                  />
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
          
          <div className="flex-shrink-0 flex border-t border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center">
              <div className="flex-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const newTheme = currentTheme === "light" ? "dark" : "light";
                    setCurrentTheme(newTheme);
                    
                    // Update user preferences if logged in
                    try {
                      User.updateMyUserData({ theme: newTheme });
                    } catch (error) {
                      console.log("Not logged in, theme not saved");
                    }
                  }}
                  className="mr-2"
                >
                  {currentTheme === "light" ? (
                    <Moon className="h-5 w-5" />
                  ) : (
                    <Sun className="h-5 w-5" />
                  )}
                </Button>
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
                    setCurrentTheme(systemTheme);
                    
                    // Update user preferences if logged in
                    try {
                      User.updateMyUserData({ theme: "system" });
                    } catch (error) {
                      console.log("Not logged in, theme not saved");
                    }
                  }}
                >
                  <Monitor className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content area */}
      <div className="md:pl-64 flex flex-col flex-1">
        <div className="sticky top-0 z-10 md:hidden pl-1 pt-1 sm:pl-3 sm:pt-3 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
          <button
            type="button"
            className="-ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500 dark:text-gray-400 dark:hover:text-white"
            onClick={() => setSidebarOpen(true)}
          >
            <span className="sr-only">Open sidebar</span>
            <Menu className="h-6 w-6" aria-hidden="true" />
          </button>
        </div>
        <main className="flex-1 relative overflow-y-auto focus:outline-none bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
          {children}
        </main>
      </div>
    </div>
  );
}

