
import React, { useState, useEffect } from "react";
import { format } from "date-fns";
import { Task } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Search,
  CheckSquare,
  Timer,
  Calendar,
  AlertTriangle,
  Tag,
  ListFilter,
  Check,
  Clock,
  FilterX,
  Pause,
  Play,
  Calendar as CalendarIcon,
  Repeat,
  Trash2
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import TaskModal from "../components/task/TaskModal";
import TaskItem from "../components/task/TaskItem";
import { Checkbox } from "@/components/ui/checkbox";

export default function TasksPage() {
  const [tasks, setTasks] = useState([]);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewFilter, setViewFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [deleteAlert, setDeleteAlert] = useState({ show: false, taskId: null });
  const [pauseAlert, setPauseAlert] = useState({ show: false, task: null });
  const [loading, setLoading] = useState(true);
  const [bulkActionMode, setBulkActionMode] = useState(false);
  const [selectedTasks, setSelectedTasks] = useState([]);

  useEffect(() => {
    loadTasks();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [tasks, searchQuery, viewFilter, categoryFilter, priorityFilter, statusFilter]);

  const loadTasks = async () => {
    setLoading(true);
    try {
      const allTasks = await Task.list("-created_date");
      setTasks(allTasks);
    } catch (error) {
      console.error("Error loading tasks:", error);
    }
    setLoading(false);
  };

  const applyFilters = () => {
    let filtered = [...tasks];
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(task => 
        task.title.toLowerCase().includes(query) || 
        (task.description && task.description.toLowerCase().includes(query)) ||
        (task.tags && task.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }
    
    // Apply status filter
    if (viewFilter !== "all") {
      if (viewFilter === "completed") {
        filtered = filtered.filter(task => task.completed);
      } else if (viewFilter === "pending") {
        filtered = filtered.filter(task => !task.completed);
      } else if (viewFilter === "today") {
        const today = format(new Date(), "yyyy-MM-dd");
        filtered = filtered.filter(task => task.scheduled_date === today);
      } else if (viewFilter === "upcoming") {
        const today = format(new Date(), "yyyy-MM-dd");
        filtered = filtered.filter(task => 
          task.scheduled_date && task.scheduled_date > today
        );
      } else if (viewFilter === "overdue") {
        const today = format(new Date(), "yyyy-MM-dd");
        filtered = filtered.filter(task => 
          !task.completed && task.scheduled_date && task.scheduled_date < today
        );
      } else if (viewFilter === "recurring") {
        filtered = filtered.filter(task => task.recurring);
      }
    }
    
    // Apply category filter
    if (categoryFilter !== "all") {
      filtered = filtered.filter(task => task.category === categoryFilter);
    }
    
    // Apply priority filter
    if (priorityFilter !== "all") {
      filtered = filtered.filter(task => task.priority === priorityFilter);
    }
    
    // Apply task status filter (paused, active)
    if (statusFilter !== "all") {
      filtered = filtered.filter(task => task.status === statusFilter);
    }
    
    setFilteredTasks(filtered);
  };

  const handleSaveTask = async (taskData) => {
    try {
      if (taskData.id) {
        await Task.update(taskData.id, taskData);
      } else {
        await Task.create(taskData);
      }
      
      setIsTaskModalOpen(false);
      setCurrentTask(null);
      loadTasks();
    } catch (error) {
      console.error("Error saving task:", error);
    }
  };

  const handleTaskAction = async (action, task) => {
    try {
      switch (action) {
        case "complete":
          const isCompleted = !task.completed;
          const completedAt = isCompleted ? new Date().toISOString() : null;
          
          await Task.update(task.id, { 
            completed: isCompleted, 
            completed_at: completedAt 
          });
          break;
          
        case "edit":
          setCurrentTask(task);
          setIsTaskModalOpen(true);
          break;
          
        case "delete":
          setDeleteAlert({ show: true, taskId: task });
          break;
          
        case "duplicate":
          const { id, created_date, updated_date, completed, completed_at, ...taskToDuplicate } = task;
          setCurrentTask({
            ...taskToDuplicate,
            title: `Copy of ${taskToDuplicate.title}`
          });
          setIsTaskModalOpen(true);
          break;
          
        case "pause":
          setPauseAlert({ show: true, task: task });
          break;
          
        case "resume":
          await Task.update(task.id, { status: "active" });
          break;
          
        case "select":
          if (selectedTasks.includes(task.id)) {
            setSelectedTasks(selectedTasks.filter(id => id !== task.id));
          } else {
            setSelectedTasks([...selectedTasks, task.id]);
          }
          break;
          
        default:
          break;
      }
      
      loadTasks();
    } catch (error) {
      console.error(`Error handling task action ${action}:`, error);
    }
  };

  const handleBulkAction = async (action) => {
    try {
      switch (action) {
        case "complete":
          await Promise.all(
            selectedTasks.map(taskId => 
              Task.update(taskId, { 
                completed: true,
                completed_at: new Date().toISOString()
              })
            )
          );
          break;
          
        case "delete":
          await Promise.all(
            selectedTasks.map(taskId => Task.delete(taskId))
          );
          break;
          
        case "reschedule":
          // Would open a dialog to select new date for all
          // For simplicity, rescheduling to tomorrow
          const tomorrow = new Date();
          tomorrow.setDate(tomorrow.getDate() + 1);
          
          await Promise.all(
            selectedTasks.map(taskId => 
              Task.update(taskId, { 
                scheduled_date: format(tomorrow, "yyyy-MM-dd")
              })
            )
          );
          break;
          
        default:
          break;
      }
      
      setSelectedTasks([]);
      setBulkActionMode(false);
      loadTasks();
    } catch (error) {
      console.error(`Error handling bulk action ${action}:`, error);
    }
  };

  const confirmDeleteTask = async () => {
    if (deleteAlert.taskId) {
      await Task.delete(deleteAlert.taskId);
      setDeleteAlert({ show: false, taskId: null });
      loadTasks();
    }
  };

  const confirmPauseTask = async () => {
    if (pauseAlert.task) {
      await Task.update(pauseAlert.task.id, { status: "paused" });
      setPauseAlert({ show: false, task: null });
      loadTasks();
    }
  };

  const resetFilters = () => {
    setSearchQuery("");
    setViewFilter("all");
    setCategoryFilter("all");
    setPriorityFilter("all");
    setStatusFilter("all");
  };

  const getFilterCounts = () => {
    const counts = {
      all: tasks.length,
      completed: tasks.filter(task => task.completed).length,
      pending: tasks.filter(task => !task.completed).length,
      today: tasks.filter(task => task.scheduled_date === format(new Date(), "yyyy-MM-dd")).length,
      upcoming: tasks.filter(task => task.scheduled_date && task.scheduled_date > format(new Date(), "yyyy-MM-dd")).length,
      overdue: tasks.filter(task => !task.completed && task.scheduled_date && task.scheduled_date < format(new Date(), "yyyy-MM-dd")).length,
      recurring: tasks.filter(task => task.recurring).length,
      paused: tasks.filter(task => task.status === "paused").length
    };
    
    return counts;
  };

  const filterCounts = getFilterCounts();
  const isFiltering = searchQuery || viewFilter !== "all" || categoryFilter !== "all" || priorityFilter !== "all" || statusFilter !== "all";

  // Get distinct categories for filter dropdown
  const categories = [...new Set(tasks.map(task => task.category))].filter(Boolean);

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Task Manager</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Organize and manage all your tasks
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2 mt-4 md:mt-0">
          {bulkActionMode && selectedTasks.length > 0 ? (
            <>
              <span className="text-sm font-medium mr-2">
                {selectedTasks.length} selected
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction("complete")}
              >
                <Check className="mr-1 h-4 w-4" />
                Complete All
              </Button>
              <Button 
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction("reschedule")}
              >
                <CalendarIcon className="mr-1 h-4 w-4" />
                Reschedule
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction("delete")}
                className="text-red-600 hover:bg-red-50"
              >
                <Trash2 className="mr-1 h-4 w-4" />
                Delete All
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setBulkActionMode(false);
                  setSelectedTasks([]);
                }}
              >
                Cancel
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={() => setBulkActionMode(true)}
                className="mr-2"
              >
                <CheckSquare className="mr-2 h-4 w-4" />
                Bulk Actions
              </Button>
              <Button
                onClick={() => {
                  setCurrentTask(null);
                  setIsTaskModalOpen(true);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Plus className="mr-2 h-4 w-4" /> New Task
              </Button>
            </>
          )}
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-medium flex flex-col sm:flex-row sm:items-center justify-between">
            <span className="flex items-center">
              <ListFilter className="mr-2 h-5 w-5 text-blue-500" />
              Filters & Search
            </span>
            
            {isFiltering && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={resetFilters}
                className="mt-2 sm:mt-0"
              >
                <FilterX className="mr-2 h-4 w-4" />
                Clear Filters
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search tasks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center">
                  <Check className="mr-2 h-4 w-4 text-gray-500" />
                  Status
                </label>
                <Select value={viewFilter} onValueChange={setViewFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Tasks ({filterCounts.all})</SelectItem>
                    <SelectItem value="pending">Pending ({filterCounts.pending})</SelectItem>
                    <SelectItem value="completed">Completed ({filterCounts.completed})</SelectItem>
                    <SelectItem value="today">Today ({filterCounts.today})</SelectItem>
                    <SelectItem value="upcoming">Upcoming ({filterCounts.upcoming})</SelectItem>
                    <SelectItem value="overdue">Overdue ({filterCounts.overdue})</SelectItem>
                    <SelectItem value="recurring">Recurring ({filterCounts.recurring})</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center">
                  <Tag className="mr-2 h-4 w-4 text-gray-500" />
                  Category
                </label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="work">Work</SelectItem>
                    <SelectItem value="personal">Personal</SelectItem>
                    <SelectItem value="health">Health</SelectItem>
                    <SelectItem value="learning">Learning</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center">
                  <AlertTriangle className="mr-2 h-4 w-4 text-gray-500" />
                  Priority
                </label>
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center">
                  <Pause className="mr-2 h-4 w-4 text-gray-500" />
                  Task State
                </label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select state" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All States</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paused">Paused ({filterCounts.paused})</SelectItem>
                    <SelectItem value="missed">Missed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="w-full grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7">
          <TabsTrigger value="all" className="flex items-center">
            <CheckSquare className="mr-2 h-4 w-4" />
            All
            <Badge className="ml-2" variant="secondary">
              {filteredTasks.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="due-today" className="flex items-center">
            <Clock className="mr-2 h-4 w-4" />
            Today
            <Badge className="ml-2" variant="secondary">
              {filteredTasks.filter(t => t.scheduled_date === format(new Date(), "yyyy-MM-dd")).length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="important" className="flex items-center">
            <AlertTriangle className="mr-2 h-4 w-4" />
            Important
            <Badge className="ml-2" variant="secondary">
              {filteredTasks.filter(t => t.priority === "high" || t.priority === "urgent").length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="upcoming" className="flex items-center">
            <Calendar className="mr-2 h-4 w-4" />
            Upcoming
            <Badge className="ml-2" variant="secondary">
              {filteredTasks.filter(t => t.scheduled_date && t.scheduled_date > format(new Date(), "yyyy-MM-dd")).length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="recurring" className="flex items-center">
            <Repeat className="mr-2 h-4 w-4" />
            Recurring
            <Badge className="ml-2" variant="secondary">
              {filteredTasks.filter(t => t.recurring).length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="paused" className="flex items-center">
            <Pause className="mr-2 h-4 w-4" />
            Paused
            <Badge className="ml-2" variant="secondary">
              {filteredTasks.filter(t => t.status === "paused").length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex items-center">
            <Check className="mr-2 h-4 w-4" />
            Completed
            <Badge className="ml-2" variant="secondary">
              {filteredTasks.filter(t => t.completed).length}
            </Badge>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                    <CheckSquare className="h-6 w-6 text-gray-400" />
                  </div>
                  {isFiltering ? (
                    <>
                      <p className="text-gray-500 dark:text-gray-400 mb-4">No tasks match your filters</p>
                      <Button onClick={resetFilters}>Clear Filters</Button>
                    </>
                  ) : (
                    <>
                      <p className="text-gray-500 dark:text-gray-400 mb-4">You don't have any tasks yet</p>
                      <Button 
                        onClick={() => {
                          setCurrentTask(null);
                          setIsTaskModalOpen(true);
                        }}
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Create Your First Task
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            ) : (
              filteredTasks.map(task => (
                <div key={task.id} className="group relative">
                  {bulkActionMode && (
                    <div className="absolute -left-8 top-1/2 -translate-y-1/2">
                      <Checkbox 
                        checked={selectedTasks.includes(task.id)}
                        onCheckedChange={() => handleTaskAction("select", task)}
                      />
                    </div>
                  )}
                  <TaskItem
                    task={task}
                    onComplete={(task) => handleTaskAction("complete", task)}
                    onEdit={(task) => handleTaskAction("edit", task)}
                    onDelete={(id) => handleTaskAction("delete", {id})}
                    onDuplicate={(task) => handleTaskAction("duplicate", task)}
                  />
                  
                  {/* Add pause/resume button */}
                  {!task.completed && !bulkActionMode && (
                    <div className="absolute right-16 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                      {task.status === "paused" ? (
                        <Button
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleTaskAction("resume", task)}
                          className="text-blue-600"
                        >
                          <Play className="h-4 w-4" />
                          <span className="sr-only">Resume</span>
                        </Button>
                      ) : (
                        <Button
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleTaskAction("pause", task)}
                          className="text-amber-600"
                        >
                          <Pause className="h-4 w-4" />
                          <span className="sr-only">Pause</span>
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="due-today" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.filter(t => t.scheduled_date === format(new Date(), "yyyy-MM-dd")).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                    <Timer className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No tasks due today</p>
                  <Button 
                    onClick={() => {
                      setCurrentTask({
                        scheduled_date: format(new Date(), "yyyy-MM-dd"),
                        scheduled_time: format(new Date(), "HH:mm")
                      });
                      setIsTaskModalOpen(true);
                    }}
                  >
                    Add Task for Today
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredTasks
                .filter(t => t.scheduled_date === format(new Date(), "yyyy-MM-dd"))
                .map(task => (
                  <div key={task.id} className="group relative">
                    {bulkActionMode && (
                      <div className="absolute -left-8 top-1/2 -translate-y-1/2">
                        <Checkbox 
                          checked={selectedTasks.includes(task.id)}
                          onCheckedChange={() => handleTaskAction("select", task)}
                        />
                      </div>
                    )}
                    <TaskItem
                      task={task}
                      onComplete={(task) => handleTaskAction("complete", task)}
                      onEdit={(task) => handleTaskAction("edit", task)}
                      onDelete={(id) => handleTaskAction("delete", {id})}
                      onDuplicate={(task) => handleTaskAction("duplicate", task)}
                    />
                    
                    {!task.completed && !bulkActionMode && (
                      <div className="absolute right-16 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                        {task.status === "paused" ? (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("resume", task)}
                            className="text-blue-600"
                          >
                            <Play className="h-4 w-4" />
                            <span className="sr-only">Resume</span>
                          </Button>
                        ) : (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("pause", task)}
                            className="text-amber-600"
                          >
                            <Pause className="h-4 w-4" />
                            <span className="sr-only">Pause</span>
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="important" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.filter(t => t.priority === "high" || t.priority === "urgent").length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                    <AlertTriangle className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No important tasks</p>
                  <Button 
                    onClick={() => {
                      setCurrentTask({
                        priority: "high"
                      });
                      setIsTaskModalOpen(true);
                    }}
                  >
                    Add Important Task
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredTasks
                .filter(t => t.priority === "high" || t.priority === "urgent")
                .map(task => (
                  <div key={task.id} className="group relative">
                    {bulkActionMode && (
                      <div className="absolute -left-8 top-1/2 -translate-y-1/2">
                        <Checkbox 
                          checked={selectedTasks.includes(task.id)}
                          onCheckedChange={() => handleTaskAction("select", task)}
                        />
                      </div>
                    )}
                    <TaskItem
                      task={task}
                      onComplete={(task) => handleTaskAction("complete", task)}
                      onEdit={(task) => handleTaskAction("edit", task)}
                      onDelete={(id) => handleTaskAction("delete", {id})}
                      onDuplicate={(task) => handleTaskAction("duplicate", task)}
                    />
                    
                    {!task.completed && !bulkActionMode && (
                      <div className="absolute right-16 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                        {task.status === "paused" ? (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("resume", task)}
                            className="text-blue-600"
                          >
                            <Play className="h-4 w-4" />
                            <span className="sr-only">Resume</span>
                          </Button>
                        ) : (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("pause", task)}
                            className="text-amber-600"
                          >
                            <Pause className="h-4 w-4" />
                            <span className="sr-only">Pause</span>
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="upcoming" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.filter(t => t.scheduled_date && t.scheduled_date > format(new Date(), "yyyy-MM-dd")).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                    <Calendar className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No upcoming tasks</p>
                  <Button 
                    onClick={() => {
                      const tomorrow = new Date();
                      tomorrow.setDate(tomorrow.getDate() + 1);
                      setCurrentTask({
                        scheduled_date: format(tomorrow, "yyyy-MM-dd"),
                        scheduled_time: "09:00"
                      });
                      setIsTaskModalOpen(true);
                    }}
                  >
                    Plan a Future Task
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredTasks
                .filter(t => t.scheduled_date && t.scheduled_date > format(new Date(), "yyyy-MM-dd"))
                .map(task => (
                  <div key={task.id} className="group relative">
                    {bulkActionMode && (
                      <div className="absolute -left-8 top-1/2 -translate-y-1/2">
                        <Checkbox 
                          checked={selectedTasks.includes(task.id)}
                          onCheckedChange={() => handleTaskAction("select", task)}
                        />
                      </div>
                    )}
                    <TaskItem
                      task={task}
                      onComplete={(task) => handleTaskAction("complete", task)}
                      onEdit={(task) => handleTaskAction("edit", task)}
                      onDelete={(id) => handleTaskAction("delete", {id})}
                      onDuplicate={(task) => handleTaskAction("duplicate", task)}
                    />
                    
                    {!task.completed && !bulkActionMode && (
                      <div className="absolute right-16 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                        {task.status === "paused" ? (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("resume", task)}
                            className="text-blue-600"
                          >
                            <Play className="h-4 w-4" />
                            <span className="sr-only">Resume</span>
                          </Button>
                        ) : (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("pause", task)}
                            className="text-amber-600"
                          >
                            <Pause className="h-4 w-4" />
                            <span className="sr-only">Pause</span>
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="recurring" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.filter(t => t.recurring).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                    <Repeat className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No recurring tasks</p>
                  <Button 
                    onClick={() => {
                      setCurrentTask({
                        recurring: true
                      });
                      setIsTaskModalOpen(true);
                    }}
                  >
                    Add Recurring Task
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredTasks
                .filter(t => t.recurring)
                .map(task => (
                  <div key={task.id} className="group relative">
                    {bulkActionMode && (
                      <div className="absolute -left-8 top-1/2 -translate-y-1/2">
                        <Checkbox 
                          checked={selectedTasks.includes(task.id)}
                          onCheckedChange={() => handleTaskAction("select", task)}
                        />
                      </div>
                    )}
                    <TaskItem
                      task={task}
                      onComplete={(task) => handleTaskAction("complete", task)}
                      onEdit={(task) => handleTaskAction("edit", task)}
                      onDelete={(id) => handleTaskAction("delete", {id})}
                      onDuplicate={(task) => handleTaskAction("duplicate", task)}
                    />
                    
                    {!task.completed && !bulkActionMode && (
                      <div className="absolute right-16 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                        {task.status === "paused" ? (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("resume", task)}
                            className="text-blue-600"
                          >
                            <Play className="h-4 w-4" />
                            <span className="sr-only">Resume</span>
                          </Button>
                        ) : (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("pause", task)}
                            className="text-amber-600"
                          >
                            <Pause className="h-4 w-4" />
                            <span className="sr-only">Pause</span>
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="paused" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.filter(t => t.status === "paused").length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                    <Pause className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No paused tasks</p>
                  <p className="text-sm text-gray-400 dark:text-gray-500">
                    Tasks will appear here once you pause them.
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredTasks
                .filter(t => t.status === "paused")
                .map(task => (
                  <div key={task.id} className="group relative">
                    {bulkActionMode && (
                      <div className="absolute -left-8 top-1/2 -translate-y-1/2">
                        <Checkbox 
                          checked={selectedTasks.includes(task.id)}
                          onCheckedChange={() => handleTaskAction("select", task)}
                        />
                      </div>
                    )}
                    <TaskItem
                      task={task}
                      onComplete={(task) => handleTaskAction("complete", task)}
                      onEdit={(task) => handleTaskAction("edit", task)}
                      onDelete={(id) => handleTaskAction("delete", {id})}
                      onDuplicate={(task) => handleTaskAction("duplicate", task)}
                    />
                    
                    {!task.completed && !bulkActionMode && (
                      <div className="absolute right-16 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                        {task.status === "paused" ? (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("resume", task)}
                            className="text-blue-600"
                          >
                            <Play className="h-4 w-4" />
                            <span className="sr-only">Resume</span>
                          </Button>
                        ) : (
                          <Button
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleTaskAction("pause", task)}
                            className="text-amber-600"
                          >
                            <Pause className="h-4 w-4" />
                            <span className="sr-only">Pause</span>
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="completed" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.filter(t => t.completed).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                    <Check className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No completed tasks yet</p>
                  <p className="text-sm text-gray-400 dark:text-gray-500">
                    Tasks will appear here once you mark them as completed
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredTasks
                .filter(t => t.completed)
                .map(task => (
                  <div key={task.id} className="group relative">
                    {bulkActionMode && (
                      <div className="absolute -left-8 top-1/2 -translate-y-1/2">
                        <Checkbox 
                          checked={selectedTasks.includes(task.id)}
                          onCheckedChange={() => handleTaskAction("select", task)}
                        />
                      </div>
                    )}
                    <TaskItem
                      task={task}
                      onComplete={(task) => handleTaskAction("complete", task)}
                      onEdit={(task) => handleTaskAction("edit", task)}
                      onDelete={(id) => handleTaskAction("delete", {id})}
                      onDuplicate={(task) => handleTaskAction("duplicate", task)}
                    />
                  </div>
                ))
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Task Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setCurrentTask(null);
        }}
        onSave={handleSaveTask}
        initialTask={currentTask}
      />
      
      {/* Delete Confirmation */}
      <AlertDialog 
        open={deleteAlert.show} 
        onOpenChange={(open) => !open && setDeleteAlert({ show: false, taskId: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this task and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTask}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Pause Confirmation */}
      <AlertDialog 
        open={pauseAlert.show} 
        onOpenChange={(open) => !open && setPauseAlert({ show: false, task: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Pause Task</AlertDialogTitle>
            <AlertDialogDescription>
              This will pause "{pauseAlert.task?.title}". Paused tasks won't appear in your daily schedule until resumed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmPauseTask}>
              Pause Task
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
