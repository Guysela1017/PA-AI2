
import React, { useState, useEffect } from "react";
import { format, addDays, parseISO } from "date-fns";
import { Task } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, ArrowRight, Sparkles } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DateNavigator from "../components/common/DateNavigator";
import TaskModal from "../components/task/TaskModal";
import TaskItem from "../components/task/TaskItem";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { User } from "@/api/entities/user";
import { Loader2 } from "lucide-react";

export default function ThreeDayView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [tasks, setTasks] = useState([]);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [deleteAlert, setDeleteAlert] = useState({ show: false, taskId: null });
  const [currentDay, setCurrentDay] = useState(0); // 0, 1, or 2 for the three days
  const [loading, setLoading] = useState(true);
  const [isAutoScheduling, setIsAutoScheduling] = useState(false);
  const [userPreferences, setUserPreferences] = useState(null);

  useEffect(() => {
    loadData();
  }, [currentDate]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load tasks and user preferences
      const [allTasks, userData] = await Promise.all([
        Task.list(),
        User.me()
      ]);
      
      setTasks(allTasks);
      setUserPreferences(userData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };

  // Calculate available time slots for a given day
  const getAvailableSlots = (date, existingTasks) => {
    const workStart = userPreferences?.preferred_working_hours?.start || "09:00";
    const workEnd = userPreferences?.preferred_working_hours?.end || "17:00";
    
    const [startHour] = workStart.split(':').map(Number);
    const [endHour] = workEnd.split(':').map(Number);
    
    // Create 30-minute slots
    const slots = [];
    for (let hour = startHour; hour < endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const slotStart = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        slots.push({
          start: slotStart,
          available: true
        });
      }
    }
    
    // Mark slots as unavailable based on existing tasks
    existingTasks.forEach(task => {
      if (task.scheduled_time) {
        const [taskHour, taskMinute] = task.scheduled_time.split(':').map(Number);
        const taskDuration = task.duration || 30; // Default 30 minutes
        const slotsNeeded = Math.ceil(taskDuration / 30);
        
        // Mark slots as unavailable
        for (let i = 0; i < slotsNeeded; i++) {
          const slotIndex = (taskHour - startHour) * 2 + Math.floor(taskMinute / 30) + i;
          if (slots[slotIndex]) {
            slots[slotIndex].available = false;
          }
        }
      }
    });
    
    return slots;
  };

  // Find best slot for a task based on preferences and availability
  const findBestSlot = (task, date, availableSlots) => {
    const energyPattern = userPreferences?.energy_pattern || "consistent";
    const focusTimes = userPreferences?.focus_times || [];
    
    // Get day of week
    const dayOfWeek = format(date, "EEEE").toLowerCase();
    
    // Check if there's a focus time block for this day
    const dayFocusTime = focusTimes.find(ft => 
      ft.days.includes(dayOfWeek)
    );
    
    // Score each available slot
    const slotScores = availableSlots
      .map((slot, index) => {
        if (!slot.available) return { index, score: -1 };
        
        let score = 0;
        const [hour] = slot.start.split(':').map(Number);
        
        // Score based on energy pattern
        switch (energyPattern) {
          case "morning_person":
            score += hour < 12 ? 3 : hour < 15 ? 2 : 1;
            break;
          case "night_owl":
            score += hour > 15 ? 3 : hour > 12 ? 2 : 1;
            break;
          case "afternoon_peak":
            score += (hour >= 13 && hour <= 16) ? 3 : 2;
            break;
          default: // consistent
            score += 2;
        }
        
        // Bonus for focus time blocks
        if (dayFocusTime) {
          const [focusStart] = dayFocusTime.start.split(':').map(Number);
          const [focusEnd] = dayFocusTime.end.split(':').map(Number);
          if (hour >= focusStart && hour < focusEnd) {
            score += 2;
          }
        }
        
        // Priority bonus
        if (task.priority === "urgent") score += 3;
        if (task.priority === "high") score += 2;
        
        // Bonus for high-energy tasks during high-energy times
        if (task.energy_required === "high" && score >= 3) score += 1;
        
        return { index, score };
      })
      .filter(slot => slot.score >= 0)
      .sort((a, b) => b.score - a.score);
    
    return slotScores[0]?.index !== undefined ? availableSlots[slotScores[0].index] : null;
  };

  // Auto-schedule unscheduled tasks
  const handleAutoSchedule = async () => {
    setIsAutoScheduling(true);
    try {
      // Get unscheduled tasks with priority
      const unscheduledTasks = tasks
        .filter(task => !task.scheduled_date && !task.completed)
        .sort((a, b) => {
          const priorityOrder = { urgent: 3, high: 2, medium: 1, low: 0 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        });
      
      // For each of the next 3 days
      const scheduleUpdates = [];
      for (let dayOffset = 0; dayOffset < 3; dayOffset++) {
        const date = addDays(currentDate, dayOffset);
        const dateStr = format(date, "yyyy-MM-dd");
        
        // Get existing tasks for this day
        const existingTasks = tasks.filter(task => task.scheduled_date === dateStr);
        
        // Get available slots
        const availableSlots = getAvailableSlots(date, existingTasks);
        
        // Try to schedule remaining unscheduled tasks
        for (let i = 0; i < unscheduledTasks.length; i++) {
          const task = unscheduledTasks[i];
          const bestSlot = findBestSlot(task, date, availableSlots);
          
          if (bestSlot) {
            // Add task to updates
            scheduleUpdates.push({
              taskId: task.id,
              updates: {
                scheduled_date: dateStr,
                scheduled_time: bestSlot.start
              }
            });
            
            // Remove task from unscheduled list
            unscheduledTasks.splice(i, 1);
            i--; // Adjust index
            
            // Mark slots as unavailable
            const slotsNeeded = Math.ceil((task.duration || 30) / 30);
            const slotIndex = availableSlots.findIndex(s => s.start === bestSlot.start);
            for (let j = 0; j < slotsNeeded && slotIndex + j < availableSlots.length; j++) {
              availableSlots[slotIndex + j].available = false;
            }
          }
        }
      }
      
      // Apply all updates
      await Promise.all(
        scheduleUpdates.map(update => 
          Task.update(update.taskId, update.updates)
        )
      );
      
      // Reload data
      loadData();
      
      // Show success toast or notification
      console.log(`Auto-scheduled ${scheduleUpdates.length} tasks`);
      
    } catch (error) {
      console.error("Error auto-scheduling tasks:", error);
    }
    setIsAutoScheduling(false);
  };

  const handleSaveTask = async (taskData) => {
    try {
      if (taskData.id) {
        await Task.update(taskData.id, taskData);
      } else {
        await Task.create(taskData);
      }
      
      setIsTaskModalOpen(false);
      setCurrentTask(null);
      loadData();
    } catch (error) {
      console.error("Error saving task:", error);
    }
  };

  const handleTaskAction = async (action, task) => {
    switch (action) {
      case "complete":
        const isCompleted = !task.completed;
        const completedAt = isCompleted ? new Date().toISOString() : null;
        
        await Task.update(task.id, { 
          completed: isCompleted, 
          completed_at: completedAt 
        });
        loadData();
        break;
        
      case "edit":
        setCurrentTask(task);
        setIsTaskModalOpen(true);
        break;
        
      case "delete":
        setDeleteAlert({ show: true, taskId: task });
        break;
        
      case "duplicate":
        const { id, created_date, updated_date, completed, completed_at, ...taskToDuplicate } = task;
        setCurrentTask({
          ...taskToDuplicate,
          title: `Copy of ${taskToDuplicate.title}`
        });
        setIsTaskModalOpen(true);
        break;
        
      default:
        break;
    }
  };

  const confirmDeleteTask = async () => {
    if (deleteAlert.taskId) {
      await Task.delete(deleteAlert.taskId);
      setDeleteAlert({ show: false, taskId: null });
      loadData();
    }
  };

  // Get tasks for the three days
  const getTasksForDay = (dayOffset) => {
    const date = addDays(currentDate, dayOffset);
    const dateStr = format(date, "yyyy-MM-dd");
    return tasks.filter(task => task.scheduled_date === dateStr);
  };

  const days = [0, 1, 2].map(offset => {
    const date = addDays(currentDate, offset);
    return {
      date,
      formattedDate: format(date, "EEEE, MMM d"),
      isToday: format(date, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd"),
      tasks: getTasksForDay(offset)
    };
  });

  // Add Auto-Schedule button to the header
  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">3-Day View</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Plan ahead with a three-day overview
          </p>
        </div>
        
        <div className="flex items-center gap-2 mt-4 md:mt-0">
          <Button
            variant="outline"
            onClick={handleAutoSchedule}
            disabled={isAutoScheduling}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            {isAutoScheduling ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Scheduling...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Auto-Schedule
              </>
            )}
          </Button>
          
          <Button
            onClick={() => {
              // Pre-populate with the selected day
              const preselectedDate = format(addDays(currentDate, currentDay), "yyyy-MM-dd");
              setCurrentTask({ 
                scheduled_date: preselectedDate,
                scheduled_time: "09:00"
              });
              setIsTaskModalOpen(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="mr-2 h-4 w-4" /> New Task
          </Button>
        </div>
      </div>
      
      <DateNavigator
        currentDate={currentDate}
        onDateChange={setCurrentDate}
        viewType="3day"
        className="mb-6"
      />
      
      <Tabs 
        defaultValue="0" 
        value={currentDay.toString()}
        onValueChange={value => setCurrentDay(parseInt(value))}
        className="mb-6"
      >
        <TabsList className="grid grid-cols-3 mb-6">
          {days.map((day, index) => (
            <TabsTrigger 
              key={index} 
              value={index.toString()}
              className={day.isToday ? "text-blue-600 font-medium" : ""}
            >
              <div className="flex flex-col items-center">
                <span className="font-medium">{format(day.date, "EEE")}</span>
                <span className={`text-sm ${day.isToday ? "bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded-full" : "text-gray-500 dark:text-gray-400"}`}>
                  {format(day.date, "MMM d")}
                </span>
              </div>
            </TabsTrigger>
          ))}
        </TabsList>
        
        {days.map((day, index) => (
          <TabsContent key={index} value={index.toString()} className="space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl font-medium flex items-center justify-between">
                  <span>
                    {day.formattedDate}
                    {day.isToday && (
                      <span className="ml-2 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 text-xs px-2 py-0.5 rounded-full">
                        Today
                      </span>
                    )}
                  </span>
                  <span className="text-sm font-normal text-gray-500 dark:text-gray-400">
                    {day.tasks.length} task{day.tasks.length !== 1 ? 's' : ''}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {day.tasks.length > 0 ? (
                  <div>
                    {/* Morning section */}
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 flex items-center">
                      <span className="bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 p-1 rounded mr-2">☀️</span>
                      Morning (Before 12pm)
                    </h3>
                    <div className="space-y-3 mb-6">
                      {day.tasks
                        .filter(task => {
                          const hour = parseInt(task.scheduled_time?.split(':')[0] || "0");
                          return hour < 12;
                        })
                        .sort((a, b) => a.scheduled_time?.localeCompare(b.scheduled_time))
                        .map(task => (
                          <TaskItem
                            key={task.id}
                            task={task}
                            onComplete={(task) => handleTaskAction("complete", task)}
                            onEdit={(task) => handleTaskAction("edit", task)}
                            onDelete={(id) => handleTaskAction("delete", {id})}
                            onDuplicate={(task) => handleTaskAction("duplicate", task)}
                          />
                        ))}
                    </div>
                    
                    {/* Afternoon section */}
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 flex items-center">
                      <span className="bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200 p-1 rounded mr-2">🌤️</span>
                      Afternoon (12pm - 5pm)
                    </h3>
                    <div className="space-y-3 mb-6">
                      {day.tasks
                        .filter(task => {
                          const hour = parseInt(task.scheduled_time?.split(':')[0] || "0");
                          return hour >= 12 && hour < 17;
                        })
                        .sort((a, b) => a.scheduled_time?.localeCompare(b.scheduled_time))
                        .map(task => (
                          <TaskItem
                            key={task.id}
                            task={task}
                            onComplete={(task) => handleTaskAction("complete", task)}
                            onEdit={(task) => handleTaskAction("edit", task)}
                            onDelete={(id) => handleTaskAction("delete", {id})}
                            onDuplicate={(task) => handleTaskAction("duplicate", task)}
                          />
                        ))}
                    </div>
                    
                    {/* Evening section */}
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 flex items-center">
                      <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-200 p-1 rounded mr-2">🌙</span>
                      Evening (After 5pm)
                    </h3>
                    <div className="space-y-3">
                      {day.tasks
                        .filter(task => {
                          const hour = parseInt(task.scheduled_time?.split(':')[0] || "0");
                          return hour >= 17;
                        })
                        .sort((a, b) => a.scheduled_time?.localeCompare(b.scheduled_time))
                        .map(task => (
                          <TaskItem
                            key={task.id}
                            task={task}
                            onComplete={(task) => handleTaskAction("complete", task)}
                            onEdit={(task) => handleTaskAction("edit", task)}
                            onDelete={(id) => handleTaskAction("delete", {id})}
                            onDuplicate={(task) => handleTaskAction("duplicate", task)}
                          />
                        ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="rounded-full bg-gray-100 dark:bg-gray-800 p-3 mb-4">
                      <Plus className="h-6 w-6 text-gray-400" />
                    </div>
                    <p className="text-gray-500 dark:text-gray-400 mb-4">No tasks scheduled for this day</p>
                    <Button 
                      variant="outline"
                      onClick={() => {
                        setCurrentTask({ 
                          scheduled_date: format(day.date, "yyyy-MM-dd"),
                          scheduled_time: "09:00"
                        });
                        setIsTaskModalOpen(true);
                      }}
                    >
                      Add a task
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick navigate to next day */}
            {index < 2 && (
              <div className="flex justify-center">
                <Button
                  variant="ghost"
                  onClick={() => setCurrentDay(index + 1)}
                  className="text-blue-600 dark:text-blue-400"
                >
                  View {format(days[index + 1].date, "EEEE")}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
      
      {/* Task Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setCurrentTask(null);
        }}
        onSave={handleSaveTask}
        initialTask={currentTask}
      />
      
      {/* Delete Confirmation */}
      <AlertDialog 
        open={deleteAlert.show} 
        onOpenChange={(open) => !open && setDeleteAlert({ show: false, taskId: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this task and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTask}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
