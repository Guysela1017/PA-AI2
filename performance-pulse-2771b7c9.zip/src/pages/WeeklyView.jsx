
import React, { useState, useEffect } from "react";
import { format, startOfWeek, endOfWeek, eachDayOfInterval, addDays, isSameDay } from "date-fns";
import { Task } from "@/api/entities";
import { Performance } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, PlusCircle } from "lucide-react";
import DateNavigator from "../components/common/DateNavigator";
import TaskModal from "../components/task/TaskModal";
import TaskItem from "../components/task/TaskItem";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import PerformanceTrends from "../components/weekly-view/PerformanceTrends";
import CategoryBreakdown from "../components/weekly-view/CategoryBreakdown";

export default function WeeklyView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [tasks, setTasks] = useState([]);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [deleteAlert, setDeleteAlert] = useState({ show: false, taskId: null });
  const [loading, setLoading] = useState(true);

  // Get start of week (Monday) and end of week (Sunday)
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentDate, { weekStartsOn: 1 });
  
  // Generate array of days for the week
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });

  // Add performance data state
  const [weeklyPerformance, setWeeklyPerformance] = useState([]);

  useEffect(() => {
    loadData();
  }, [currentDate]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load tasks and performance data for the week
      const [allTasks, performanceData] = await Promise.all([
        Task.list(),
        Performance.list("-date")
      ]);
      
      setTasks(allTasks);
      
      // Filter performance data for the current week
      const weekPerformance = performanceData.filter(perf => {
        const perfDate = new Date(perf.date);
        return perfDate >= weekStart && perfDate <= weekEnd;
      });
      
      setWeeklyPerformance(weekPerformance);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadTasks();
  }, [currentDate]);

  const loadTasks = async () => {
    setLoading(true);
    try {
      const allTasks = await Task.list();
      setTasks(allTasks);
    } catch (error) {
      console.error("Error loading tasks:", error);
    }
    setLoading(false);
  };

  const handleSaveTask = async (taskData) => {
    try {
      if (taskData.id) {
        await Task.update(taskData.id, taskData);
      } else {
        await Task.create(taskData);
      }
      
      setIsTaskModalOpen(false);
      setCurrentTask(null);
      loadTasks();
    } catch (error) {
      console.error("Error saving task:", error);
    }
  };

  const handleTaskAction = async (action, task) => {
    switch (action) {
      case "complete":
        const isCompleted = !task.completed;
        const completedAt = isCompleted ? new Date().toISOString() : null;
        
        await Task.update(task.id, { 
          completed: isCompleted, 
          completed_at: completedAt 
        });
        loadTasks();
        break;
        
      case "edit":
        setCurrentTask(task);
        setIsTaskModalOpen(true);
        break;
        
      case "delete":
        setDeleteAlert({ show: true, taskId: task });
        break;
        
      case "duplicate":
        const { id, created_date, updated_date, completed, completed_at, ...taskToDuplicate } = task;
        setCurrentTask({
          ...taskToDuplicate,
          title: `Copy of ${taskToDuplicate.title}`
        });
        setIsTaskModalOpen(true);
        break;
        
      default:
        break;
    }
  };

  const confirmDeleteTask = async () => {
    if (deleteAlert.taskId) {
      await Task.delete(deleteAlert.taskId);
      setDeleteAlert({ show: false, taskId: null });
      loadTasks();
    }
  };

  // Get tasks for a specific day
  const getTasksForDay = (date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    return tasks.filter(task => task.scheduled_date === dateStr);
  };

  // Calculate task stats
  const completedTasks = tasks.filter(task => task.completed).length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Weekly View</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Plan your week and manage your schedule
          </p>
        </div>
        
        <div className="flex items-center mt-4 md:mt-0">
          <Button
            onClick={() => {
              setCurrentTask(null);
              setIsTaskModalOpen(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="mr-2 h-4 w-4" /> New Task
          </Button>
        </div>
      </div>
      
      <DateNavigator
        currentDate={currentDate}
        onDateChange={setCurrentDate}
        viewType="week"
        className="mb-6"
      />
      
      {/* Add Performance Trends before the calendar grid */}
      <div className="space-y-6 mb-6">
        <PerformanceTrends weekData={weeklyPerformance} />
        <CategoryBreakdown tasks={tasks} />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-6">
        <Card className="md:col-span-3 lg:col-span-4">
          <CardHeader className="pb-0">
            <CardTitle className="text-lg font-medium flex items-center">
              Week Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2 mt-4">
              {weekDays.map((day, i) => {
                const dayTasks = getTasksForDay(day);
                const isToday = isSameDay(day, new Date());
                const completedToday = dayTasks.filter(task => task.completed).length;
                
                return (
                  <div 
                    key={i} 
                    className={`border rounded-lg transition-all
                      ${isToday ? 'border-blue-500 dark:border-blue-400 bg-blue-50 dark:bg-blue-900/20' : 
                        'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'}
                    `}
                  >
                    <div className={`p-3 text-center border-b 
                      ${isToday ? 'border-blue-200 dark:border-blue-700 bg-blue-100 dark:bg-blue-900/30' : 
                        'border-gray-200 dark:border-gray-700'}
                    `}>
                      <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
                        {format(day, "EEE")}
                      </p>
                      <p className={`text-xl font-bold ${isToday ? "text-blue-600 dark:text-blue-400" : ""}`}>
                        {format(day, "d")}
                      </p>
                    </div>
                    
                    <div className="p-3">
                      <div className="flex justify-between items-center mb-2">
                        <Badge variant="outline" className="text-xs">
                          {dayTasks.length} tasks
                        </Badge>
                        
                        {dayTasks.length > 0 && (
                          <Badge 
                            variant="outline" 
                            className={`text-xs 
                              ${completedToday === dayTasks.length && dayTasks.length > 0 
                                ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800" 
                                : "bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"}
                            `}
                          >
                            {completedToday}/{dayTasks.length}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="space-y-2 mt-3">
                        {dayTasks.slice(0, 3).map(task => (
                          <div 
                            key={task.id}
                            className={`p-2 rounded-md text-xs truncate cursor-pointer
                              ${task.completed 
                                ? "bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 line-through" 
                                : task.priority === "urgent" 
                                  ? "bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-300" 
                                  : task.priority === "high" 
                                    ? "bg-orange-50 dark: bg-orange-900/20 text-orange-800 dark:text-orange-300" 
                                    : "bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-300"}
                            `}
                            onClick={() => handleTaskAction("edit", task)}
                          >
                            {task.title}
                          </div>
                        ))}
                        
                        {dayTasks.length > 3 && (
                          <div className="text-xs text-center text-gray-500 dark:text-gray-400 mt-1">
                            +{dayTasks.length - 3} more tasks
                          </div>
                        )}
                        
                        {dayTasks.length === 0 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full h-12 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
                            onClick={() => {
                              setCurrentTask({ 
                                scheduled_date: format(day, "yyyy-MM-dd"),
                                scheduled_time: "09:00" 
                              });
                              setIsTaskModalOpen(true);
                            }}
                          >
                            <PlusCircle className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {weekDays.map((day, i) => {
          const dayTasks = getTasksForDay(day);
          if (dayTasks.length === 0) return null;
          
          const isToday = isSameDay(day, new Date());
          
          return (
            <Card key={i}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center justify-between">
                  <span className="flex items-center">
                    {format(day, "EEEE, MMM d")}
                    {isToday && (
                      <Badge className="ml-2 bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-200 dark:border-blue-700">
                        Today
                      </Badge>
                    )}
                  </span>
                  <Badge variant="outline">
                    {dayTasks.length} tasks
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {dayTasks
                    .sort((a, b) => {
                      // Sort by time, then by priority
                      if (a.scheduled_time && b.scheduled_time) {
                        return a.scheduled_time.localeCompare(b.scheduled_time);
                      }
                      
                      const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
                      return priorityOrder[a.priority] - priorityOrder[b.priority];
                    })
                    .map(task => (
                      <TaskItem
                        key={task.id}
                        task={task}
                        onComplete={(task) => handleTaskAction("complete", task)}
                        onEdit={(task) => handleTaskAction("edit", task)}
                        onDelete={(id) => handleTaskAction("delete", {id})}
                        onDuplicate={(task) => handleTaskAction("duplicate", task)}
                        compact={true}
                      />
                    ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      {/* Task Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setCurrentTask(null);
        }}
        onSave={handleSaveTask}
        initialTask={currentTask}
      />
      
      {/* Delete Confirmation */}
      <AlertDialog 
        open={deleteAlert.show} 
        onOpenChange={(open) => !open && setDeleteAlert({ show: false, taskId: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this task and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTask}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
