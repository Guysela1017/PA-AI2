import React from "react";
import { format, isBefore, isPast, addDays, parseISO, isToday } from "date-fns";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  MoreHorizontal, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Calendar, 
  Loader2, 
  ArrowRight 
} from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import TaskStatusBadge, { TASK_STATUS } from "./TaskStatusBadge";

export default function TodayTaskList({ 
  tasks = [], 
  isLoading = false, 
  onTaskAction, 
  onViewAllClick,
  className 
}) {
  // Determine task status based on task data
  const getTaskStatus = (task) => {
    if (task.completed) return TASK_STATUS.COMPLETED;
    if (task.status === 'missed') return TASK_STATUS.MISSED;
    if (task.status === 'rescheduled') return TASK_STATUS.RESCHEDULED;
    
    // Check if task is overdue
    if (task.scheduled_date && task.scheduled_time) {
      const taskDateTime = new Date(`${task.scheduled_date}T${task.scheduled_time}`);
      const now = new Date();
      
      // If task is scheduled for today but time has passed
      if (isToday(taskDateTime) && isPast(taskDateTime)) {
        return TASK_STATUS.OVERDUE;
      }
    }
    
    return TASK_STATUS.PENDING;
  };

  // Get time display from scheduled time
  const getTimeDisplay = (task) => {
    if (!task.scheduled_time) return null;
    
    try {
      const [hours, minutes] = task.scheduled_time.split(':');
      const date = new Date();
      date.setHours(parseInt(hours, 10));
      date.setMinutes(parseInt(minutes, 10));
      return format(date, 'h:mm a');
    } catch (error) {
      return task.scheduled_time;
    }
  };

  // Get appropriate background style based on task status
  const getTaskCardStyle = (task) => {
    const status = getTaskStatus(task);
    switch (status) {
      case TASK_STATUS.COMPLETED:
        return "border-l-4 border-l-green-500 bg-green-50/50 dark:bg-green-900/10";
      case TASK_STATUS.MISSED:
        return "border-l-4 border-l-red-500 bg-red-50/50 dark:bg-red-900/10";
      case TASK_STATUS.OVERDUE:
        return "border-l-4 border-l-orange-500 bg-orange-50/50 dark:bg-orange-900/10";
      case TASK_STATUS.RESCHEDULED:
        return "border-l-4 border-l-yellow-500 bg-yellow-50/50 dark:bg-yellow-900/10";
      default:
        return "";
    }
  };

  return (
    <div className={cn("space-y-4", className)}>
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Today's Tasks</h3>
        <Button variant="ghost" size="sm" onClick={onViewAllClick} className="text-blue-600">
          View All
          <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-3">
        {isLoading ? (
          // Loading skeletons
          Array(3).fill().map((_, i) => (
            <Card key={i} className="hover:shadow transition-shadow">
              <CardContent className="p-4">
                <div className="flex justify-between">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-start">
                      <Skeleton className="h-4 w-4 mr-2 mt-0.5" />
                      <Skeleton className="h-5 w-full max-w-[250px]" />
                    </div>
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <Skeleton className="h-6 w-20 rounded-full" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : tasks.length === 0 ? (
          // Empty state
          <Card className="bg-gray-50 dark:bg-gray-800/50 border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-10 text-center">
              <div className="rounded-full bg-blue-100 dark:bg-blue-900/30 p-3 mb-3">
                <CheckCircle className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">All done for today!</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 max-w-sm mt-1">
                You have no more tasks scheduled for today. Enjoy your free time or plan ahead.
              </p>
              <Button 
                variant="outline"
                size="sm" 
                className="mt-4"
                onClick={() => onTaskAction('new', {})}
              >
                Add New Task
              </Button>
            </CardContent>
          </Card>
        ) : (
          // Task list
          tasks.map(task => (
            <Card 
              key={task.id} 
              className={cn(
                "hover:shadow transition-shadow", 
                getTaskCardStyle(task),
                task.completed && "opacity-80"
              )}
            >
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-start space-x-3">
                    <Checkbox 
                      checked={task.completed}
                      disabled={task.status === 'missed'}
                      onCheckedChange={() => onTaskAction('complete', task)}
                      className="mt-1"
                    />
                    <div className="space-y-1">
                      <p className={cn(
                        "font-medium",
                        task.completed && "line-through text-gray-500 dark:text-gray-400"
                      )}>
                        {task.title}
                      </p>
                      
                      <div className="flex flex-wrap gap-2">
                        {getTimeDisplay(task) && (
                          <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                            <Clock className="h-3 w-3 mr-1" />
                            {getTimeDisplay(task)}
                          </div>
                        )}
                        
                        {task.duration && (
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {task.duration < 60 
                              ? `${task.duration}min`
                              : `${Math.floor(task.duration/60)}h${task.duration%60 ? ` ${task.duration%60}m` : ''}`
                            }
                          </div>
                        )}
                        
                        {task.priority && (
                          <Badge variant="outline" 
                            className={cn(
                              "text-xs",
                              task.priority === 'high' && "bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-800",
                              task.priority === 'urgent' && "bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800"
                            )}
                          >
                            {task.priority}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <TaskStatusBadge status={getTaskStatus(task)} />
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {!task.completed && (
                          <DropdownMenuItem onClick={() => onTaskAction('complete', task)}>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Mark Complete
                          </DropdownMenuItem>
                        )}
                        
                        {task.completed && (
                          <DropdownMenuItem onClick={() => onTaskAction('uncomplete', task)}>
                            <XCircle className="h-4 w-4 mr-2" />
                            Mark Incomplete
                          </DropdownMenuItem>
                        )}
                        
                        <DropdownMenuItem onClick={() => onTaskAction('edit', task)}>
                          <Clock className="h-4 w-4 mr-2" />
                          Edit Task
                        </DropdownMenuItem>
                        
                        {!task.completed && !task.status && (
                          <>
                            <DropdownMenuItem onClick={() => onTaskAction('reschedule', task)}>
                              <Calendar className="h-4 w-4 mr-2" />
                              Reschedule
                            </DropdownMenuItem>
                            
                            <DropdownMenuItem onClick={() => onTaskAction('mark-missed', task)}>
                              <XCircle className="h-4 w-4 mr-2" />
                              Mark as Missed
                            </DropdownMenuItem>
                          </>
                        )}
                        
                        <DropdownMenuSeparator />
                        
                        <DropdownMenuItem onClick={() => onTaskAction('delete', task)}>
                          <XCircle className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}