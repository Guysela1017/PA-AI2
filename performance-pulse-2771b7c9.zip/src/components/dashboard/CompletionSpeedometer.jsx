import React from "react";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { CheckCircle, AlertCircle } from "lucide-react";

/**
 * Dynamic speedometer showing daily completion percentage
 */
export default function CompletionSpeedometer({ 
  percentComplete, 
  totalTasks, 
  completedTasks,
  missedTasks = 0, 
  className 
}) {
  // Determine color based on completion percentage
  const getSpeedometerColor = () => {
    if (percentComplete >= 80) return "bg-green-600 dark:bg-green-500";
    if (percentComplete >= 50) return "bg-yellow-500 dark:bg-yellow-400";
    return "bg-red-500 dark:bg-red-400";
  };

  // Determine progress message
  const getProgressMessage = () => {
    if (totalTasks === 0) return "No tasks scheduled";
    if (percentComplete >= 80) return "Great progress today!";
    if (percentComplete >= 50) return "Making good progress";
    if (percentComplete >= 30) return "Keep going!";
    return "Let's get started!";
  };

  return (
    <div className={cn("relative py-4 px-1", className)}>
      {/* Main speedometer display */}
      <div className="flex flex-col items-center">
        <div className="relative w-44 h-24 mt-2 mb-4">
          {/* Semicircle background */}
          <div className="absolute w-full h-full bg-gray-100 dark:bg-gray-800 rounded-t-full overflow-hidden">
            {/* Progress arc */}
            <div 
              className={cn("absolute w-full h-full rounded-t-full transition-all duration-700", getSpeedometerColor())}
              style={{ 
                clipPath: `polygon(50% 100%, 50% 0%, 100% 0%, 100% 100%)`,
                transform: `rotate(${Math.min(180, percentComplete * 1.8)}deg)`,
                transformOrigin: '50% 100%'
              }}
            ></div>
            
            {/* Needle */}
            <div className="absolute bottom-0 left-1/2 w-1 h-24 bg-gray-700 dark:bg-gray-200 rounded-t-full z-10" 
                style={{ 
                  transform: `rotate(${Math.min(180, percentComplete * 1.8)}deg)`,
                  transformOrigin: 'bottom center',
                  transition: 'transform 1s ease-out'
                }}>
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-gray-900 dark:bg-white rounded-full"></div>
            </div>
            
            {/* Center pin */}
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-5 h-5 bg-gray-300 dark:bg-gray-600 rounded-full border-2 border-gray-500 dark:border-gray-400 z-20"></div>
          </div>
        </div>
        
        {/* Percentage display */}
        <div className="text-4xl font-bold">{percentComplete}%</div>
        <div className="text-sm text-gray-500 dark:text-gray-400">Completion Rate</div>
        <div className="mt-2 font-medium">{getProgressMessage()}</div>
      </div>
      
      {/* Stats below speedometer */}
      <div className="grid grid-cols-3 gap-2 mt-4">
        <div className="flex flex-col items-center p-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <span className="text-sm text-gray-500 dark:text-gray-400">Total</span>
          <span className="text-xl font-semibold">{totalTasks}</span>
        </div>
        <div className="flex flex-col items-center p-2 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-lg">
          <span className="text-sm flex items-center">
            <CheckCircle className="h-3 w-3 mr-1" />
            Done
          </span>
          <span className="text-xl font-semibold">{completedTasks}</span>
        </div>
        <div className="flex flex-col items-center p-2 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg">
          <span className="text-sm flex items-center">
            <AlertCircle className="h-3 w-3 mr-1" />
            Missed
          </span>
          <span className="text-xl font-semibold">{missedTasks}</span>
        </div>
      </div>
    </div>
  );
}