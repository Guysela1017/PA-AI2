import React from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Clock, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

export const TASK_STATUS = {
  COMPLETED: "completed",
  PENDING: "pending",
  MISSED: "missed",
  RESCHEDULED: "rescheduled",
  UPCOMING: "upcoming",
  OVERDUE: "overdue"
};

export default function TaskStatusBadge({ status, className }) {
  // Define styles for different statuses
  const statusConfig = {
    [TASK_STATUS.COMPLETED]: {
      icon: CheckCircle,
      text: "Completed",
      className: "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800"
    },
    [TASK_STATUS.PENDING]: {
      icon: Clock,
      text: "Pending",
      className: "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800"
    },
    [TASK_STATUS.MISSED]: {
      icon: XCircle,
      text: "Missed",
      className: "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800"
    },
    [TASK_STATUS.RESCHEDULED]: {
      icon: Clock,
      text: "Rescheduled",
      className: "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-800"
    },
    [TASK_STATUS.UPCOMING]: {
      icon: Clock,
      text: "Upcoming",
      className: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800"
    },
    [TASK_STATUS.OVERDUE]: {
      icon: AlertTriangle,
      text: "Overdue",
      className: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-800"
    },
  };

  const config = statusConfig[status] || statusConfig[TASK_STATUS.PENDING];
  const IconComponent = config.icon;

  return (
    <Badge 
      variant="outline" 
      className={cn("flex items-center gap-1", config.className, className)}
    >
      <IconComponent className="h-3 w-3" />
      {config.text}
    </Badge>
  );
}