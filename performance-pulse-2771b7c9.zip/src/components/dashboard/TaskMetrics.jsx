
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Zap,
  Brain,
  Target,
  Bell
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function TaskMetrics({ 
  tasks = [], 
  preferences,
  onUpdatePreferences,
  className = "" 
}) {
  // Calculate metrics
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.completed).length;
  const missedTasks = tasks.filter(task => task.status === "missed").length;
  const scheduledTasks = tasks.filter(task => task.scheduled_date && task.scheduled_time).length;
  
  // Calculate energy distribution
  const energyDistribution = tasks.reduce((acc, task) => {
    acc[task.energy_required] = (acc[task.energy_required] || 0) + 1;
    return acc;
  }, {});
  
  // Calculate priority distribution
  const priorityDistribution = tasks.reduce((acc, task) => {
    acc[task.priority] = (acc[task.priority] || 0) + 1;
    return acc;
  }, {});

  const getEnergyColor = (level) => {
    switch (level) {
      case "high": return "text-red-500";
      case "medium": return "text-yellow-500";
      case "low": return "text-green-500";
      default: return "text-gray-500";
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "urgent": return "text-red-500";
      case "high": return "text-orange-500";
      case "medium": return "text-yellow-500";
      case "low": return "text-green-500";
      default: return "text-gray-500";
    }
  };

  return (
    <div className={className}>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Completion Status */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Completion Rate
                </p>
                <h3 className="text-2xl font-bold mt-2">
                  {totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0}%
                </h3>
              </div>
              <CheckCircle className="h-5 w-5 text-green-500" />
            </div>
            <div className="mt-4 flex gap-2">
              <Badge variant="outline" className="bg-green-50 text-green-700">
                {completedTasks} Completed
              </Badge>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                {totalTasks - completedTasks} Pending
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Schedule Status */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Scheduled Tasks
                </p>
                <h3 className="text-2xl font-bold mt-2">
                  {scheduledTasks}/{totalTasks}
                </h3>
              </div>
              <Clock className="h-5 w-5 text-blue-500" />
            </div>
            <div className="mt-4 flex gap-2">
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                {scheduledTasks} Scheduled
              </Badge>
              <Badge variant="outline" className="bg-red-50 text-red-700">
                {missedTasks} Missed
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Energy Distribution */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Energy Level
                </p>
                <h3 className="text-2xl font-bold mt-2">
                  {Object.keys(energyDistribution).length} Types
                </h3>
              </div>
              <Zap className="h-5 w-5 text-yellow-500" />
            </div>
            <div className="mt-4 space-y-2">
              {Object.entries(energyDistribution).map(([level, count]) => (
                <div key={level} className="flex items-center justify-between">
                  <span className={`text-sm ${getEnergyColor(level)}`}>
                    {level.charAt(0).toUpperCase() + level.slice(1)}
                  </span>
                  <Badge variant="outline">
                    {count} tasks
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Priority Distribution */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Priority Levels
                </p>
                <h3 className="text-2xl font-bold mt-2">
                  {Object.keys(priorityDistribution).length} Types
                </h3>
              </div>
              <Target className="h-5 w-5 text-purple-500" />
            </div>
            <div className="mt-4 space-y-2">
              {Object.entries(priorityDistribution).map(([priority, count]) => (
                <div key={priority} className="flex items-center justify-between">
                  <span className={`text-sm ${getPriorityColor(priority)}`}>
                    {priority.charAt(0).toUpperCase() + priority.slice(1)}
                  </span>
                  <Badge variant="outline">
                    {count} tasks
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Add Notification Preferences Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Notifications
                </p>
                <h3 className="text-2xl font-bold mt-2">
                  Preferences
                </h3>
              </div>
              <Bell className="h-5 w-5 text-blue-500" />
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium">Task Reminders</p>
                  <p className="text-xs text-gray-500">
                    5 minutes before start
                  </p>
                </div>
                <Switch
                  checked={preferences?.notification_preferences?.task_reminders}
                  onCheckedChange={(checked) => 
                    onUpdatePreferences('task_reminders', checked)
                  }
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium">Daily Summary</p>
                  <p className="text-xs text-gray-500">
                    End of day recap
                  </p>
                </div>
                <Switch
                  checked={preferences?.notification_preferences?.daily_summary}
                  onCheckedChange={(checked) => 
                    onUpdatePreferences('daily_summary', checked)
                  }
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium">Weekly Insights</p>
                  <p className="text-xs text-gray-500">
                    Performance review
                  </p>
                </div>
                <Switch
                  checked={preferences?.notification_preferences?.performance_insights}
                  onCheckedChange={(checked) => 
                    onUpdatePreferences('performance_insights', checked)
                  }
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
