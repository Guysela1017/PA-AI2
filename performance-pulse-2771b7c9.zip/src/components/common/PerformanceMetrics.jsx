import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckSquare, Clock, Zap, Brain } from "lucide-react";

export default function PerformanceMetrics({ performance, className = "" }) {
  // Calculate percentages
  const completionRate = performance.tasks_completed && performance.tasks_planned 
    ? Math.round((performance.tasks_completed / performance.tasks_planned) * 100) 
    : 0;
  
  const getMetricColor = (value, metric) => {
    if (metric === "completion") {
      if (value >= 80) return "text-green-600";
      if (value >= 60) return "text-yellow-600";
      return "text-red-600";
    }
    if (metric === "energy" || metric === "focus") {
      if (value >= 8) return "text-green-600";
      if (value >= 5) return "text-yellow-600";
      return "text-red-600";
    }
    if (metric === "productivity") {
      if (value >= 75) return "text-green-600";
      if (value >= 50) return "text-yellow-600";
      return "text-red-600";
    }
  };

  const getProgressColor = (value, metric) => {
    if (metric === "completion") {
      if (value >= 80) return "bg-green-600";
      if (value >= 60) return "bg-yellow-600";
      return "bg-red-600";
    }
    if (metric === "energy" || metric === "focus") {
      const percentage = (value / 10) * 100;
      if (percentage >= 80) return "bg-green-600";
      if (percentage >= 50) return "bg-yellow-600";
      return "bg-red-600";
    }
    if (metric === "productivity") {
      if (value >= 75) return "bg-green-600";
      if (value >= 50) return "bg-yellow-600";
      return "bg-red-600";
    }
  };

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 ${className}`}>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center">
            <CheckSquare className="mr-2 h-4 w-4 text-blue-500" />
            Task Completion
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <span className="text-2xl font-bold">
              {performance.tasks_completed}/{performance.tasks_planned}
            </span>
            <span 
              className={`text-lg font-semibold ${getMetricColor(completionRate, "completion")}`}
            >
              {completionRate}%
            </span>
          </div>
          <Progress 
            value={completionRate} 
            className="h-2" 
            indicatorClassName={getProgressColor(completionRate, "completion")}
          />
          <p className="text-xs text-gray-500 mt-2">
            {completionRate < 60 
              ? "Needs improvement" 
              : completionRate < 80 
                ? "Good progress" 
                : "Excellent work!"}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center">
            <Zap className="mr-2 h-4 w-4 text-yellow-500" />
            Energy Level
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <span className="text-2xl font-bold">
              {performance.energy_level}/10
            </span>
            <span 
              className={`text-lg font-semibold ${getMetricColor(performance.energy_level, "energy")}`}
            >
              {performance.energy_level >= 8 
                ? "High" 
                : performance.energy_level >= 5 
                  ? "Medium" 
                  : "Low"}
            </span>
          </div>
          <Progress 
            value={(performance.energy_level / 10) * 100} 
            className="h-2"
            indicatorClassName={getProgressColor(performance.energy_level, "energy")}
          />
          <p className="text-xs text-gray-500 mt-2">
            {performance.energy_level < 5 
              ? "Consider rest or easier tasks" 
              : performance.energy_level < 8 
                ? "Balanced energy today" 
                : "Great energy level!"}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center">
            <Brain className="mr-2 h-4 w-4 text-purple-500" />
            Focus Score
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <span className="text-2xl font-bold">
              {performance.focus_score}/10
            </span>
            <span 
              className={`text-lg font-semibold ${getMetricColor(performance.focus_score, "focus")}`}
            >
              {performance.focus_score >= 8 
                ? "Excellent" 
                : performance.focus_score >= 5 
                  ? "Good" 
                  : "Distracted"}
            </span>
          </div>
          <Progress 
            value={(performance.focus_score / 10) * 100} 
            className="h-2"
            indicatorClassName={getProgressColor(performance.focus_score, "focus")}
          />
          <p className="text-xs text-gray-500 mt-2">
            {performance.focus_score < 5 
              ? "Try reducing distractions" 
              : performance.focus_score < 8 
                ? "Maintaining decent focus" 
                : "Excellent concentration!"}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center">
            <Clock className="mr-2 h-4 w-4 text-green-500" />
            Productivity Score
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <span className="text-2xl font-bold">
              {performance.productivity_score}/100
            </span>
            <span 
              className={`text-lg font-semibold ${getMetricColor(performance.productivity_score, "productivity")}`}
            >
              {performance.productivity_score >= 75 
                ? "High" 
                : performance.productivity_score >= 50 
                  ? "Medium" 
                  : "Low"}
            </span>
          </div>
          <Progress 
            value={performance.productivity_score} 
            className="h-2"
            indicatorClassName={getProgressColor(performance.productivity_score, "productivity")}
          />
          <p className="text-xs text-gray-500 mt-2">
            {performance.productivity_score < 50 
              ? "Room for improvement" 
              : performance.productivity_score < 75 
                ? "Solid productivity" 
                : "Peak performance!"}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}