import React, { useState } from "react";
import { format, addDays, addWeeks, addMonths, startOfWeek, startOfMonth, endOfWeek, endOfMonth } from "date-fns";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, ArrowLeft, ArrowRight } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export default function DateNavigator({ 
  currentDate, 
  onDateChange, 
  viewType = "day", // day, week, month
  className = "" 
}) {
  // Determine the format based on the view type
  const getDateFormat = () => {
    switch (viewType) {
      case "day":
        return "EEEE, MMMM d, yyyy";
      case "3day":
        const endDate = addDays(currentDate, 2);
        return `MMM d - ${format(endDate, "d, yyyy")}`;
      case "week":
        const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
        const weekEnd = endOfWeek(currentDate, { weekStartsOn: 1 });
        return `${format(weekStart, "MMM d")} - ${format(weekEnd, "MMM d, yyyy")}`;
      case "month":
        return "MMMM yyyy";
      default:
        return "MMMM d, yyyy";
    }
  };

  const handlePrevious = () => {
    switch (viewType) {
      case "day":
        onDateChange(addDays(currentDate, -1));
        break;
      case "3day":
        onDateChange(addDays(currentDate, -3));
        break;
      case "week":
        onDateChange(addWeeks(currentDate, -1));
        break;
      case "month":
        onDateChange(addMonths(currentDate, -1));
        break;
      default:
        onDateChange(addDays(currentDate, -1));
    }
  };

  const handleNext = () => {
    switch (viewType) {
      case "day":
        onDateChange(addDays(currentDate, 1));
        break;
      case "3day":
        onDateChange(addDays(currentDate, 3));
        break;
      case "week":
        onDateChange(addWeeks(currentDate, 1));
        break;
      case "month":
        onDateChange(addMonths(currentDate, 1));
        break;
      default:
        onDateChange(addDays(currentDate, 1));
    }
  };

  const handleToday = () => {
    onDateChange(new Date());
  };

  const handleCalendarSelect = (date) => {
    let selectedDate = date;
    
    // Adjust based on view type
    if (viewType === "week") {
      selectedDate = startOfWeek(date, { weekStartsOn: 1 });
    } else if (viewType === "month") {
      selectedDate = startOfMonth(date);
    }
    
    onDateChange(selectedDate);
  };

  return (
    <div className={`flex flex-col sm:flex-row items-center justify-between ${className}`}>
      <div className="flex items-center space-x-2 mb-2 sm:mb-0">
        <Button variant="outline" size="icon" onClick={handlePrevious}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="min-w-[200px] justify-start font-medium">
              <CalendarIcon className="mr-2 h-4 w-4" />
              {format(currentDate, getDateFormat())}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="bg-slate-50 text-popover-foreground p-0 z-50 rounded-md border shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 w-auto">
            <Calendar
              mode="single"
              selected={currentDate}
              onSelect={handleCalendarSelect}
              initialFocus
            />
          </PopoverContent>
        </Popover>
        
        <Button variant="outline" size="icon" onClick={handleNext}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      <Button variant="outline" onClick={handleToday} className="bg-sky-400 text-gray-800 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-input hover:bg-accent hover:text-accent-foreground h-9">
        Today
      </Button>
    </div>
  );
}