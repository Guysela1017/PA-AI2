import React from 'react';
import {
  Toast,
  ToastProvider,
  ToastViewport,
  ToastTitle,
  ToastDescription,
  ToastClose,
  ToastAction,
} from "@/components/ui/toast";
import { Bell, CheckCircle, XCircle, Clock, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const NOTIFICATION_TYPE = {
  REMINDER: 'reminder',
  COMPLETION: 'completion',
  SUMMARY: 'summary',
  PERFORMANCE: 'performance'
};

export function NotificationToast({ 
  type, 
  title, 
  description, 
  action,
  onAction,
  onDismiss,
  duration = 5000 // Default duration 5s
}) {
  const getIcon = () => {
    switch (type) {
      case NOTIFICATION_TYPE.REMINDER:
        return <Clock className="h-5 w-5 text-blue-500" />;
      case NOTIFICATION_TYPE.COMPLETION:
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case NOTIFICATION_TYPE.SUMMARY:
        return <Calendar className="h-5 w-5 text-purple-500" />;
      case NOTIFICATION_TYPE.PERFORMANCE:
        return <Bell className="h-5 w-5 text-yellow-500" />;
      default:
        return <Bell className="h-5 w-5" />;
    }
  };

  const getStyles = () => {
    switch (type) {
      case NOTIFICATION_TYPE.REMINDER:
        return "border-l-4 border-l-blue-500";
      case NOTIFICATION_TYPE.COMPLETION:
        return "border-l-4 border-l-green-500";
      case NOTIFICATION_TYPE.SUMMARY:
        return "border-l-4 border-l-purple-500";
      case NOTIFICATION_TYPE.PERFORMANCE:
        return "border-l-4 border-l-yellow-500";
      default:
        return "";
    }
  };

  return (
    <Toast className={cn("flex items-start gap-4", getStyles())}>
      <div className="p-2">
        {getIcon()}
      </div>
      <div className="flex-1 pt-2">
        <ToastTitle>{title}</ToastTitle>
        {description && (
          <ToastDescription>{description}</ToastDescription>
        )}
      </div>
      <div className="flex flex-col items-end gap-2 pt-2">
        {action && (
          <ToastAction altText={action} onClick={onAction}>
            {action}
          </ToastAction>
        )}
        <ToastClose onClick={onDismiss} />
      </div>
    </Toast>
  );
}