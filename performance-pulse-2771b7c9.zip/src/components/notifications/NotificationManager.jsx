import React, { useCallback } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { format, isToday, parseISO, addMinutes, subMinutes } from 'date-fns';
import { NotificationToast, NOTIFICATION_TYPE } from './NotificationToast';
import { Task, Performance } from '@/api/entities';

export default function NotificationManager({ tasks = [], preferences = {} }) {
  const { toast } = useToast();

  // Schedule task reminder
  const scheduleTaskReminder = useCallback((task) => {
    if (!task.scheduled_date || !task.scheduled_time) return;
    
    const taskDateTime = new Date(`${task.scheduled_date}T${task.scheduled_time}`);
    const reminderTime = subMinutes(taskDateTime, 5); // 5 minutes before
    const now = new Date();
    
    if (reminderTime > now) {
      const timeoutId = setTimeout(() => {
        if (preferences?.notification_preferences?.task_reminders) {
          toast({
            title: `Task Reminder: ${task.title}`,
            description: `Starting in 5 minutes at ${format(taskDateTime, 'h:mm a')}`,
            duration: 10000,
            type: NOTIFICATION_TYPE.REMINDER,
            action: "View Task"
          });
        }
      }, reminderTime.getTime() - now.getTime());

      // Store timeout ID for cleanup
      return timeoutId;
    }
  }, [preferences?.notification_preferences?.task_reminders]);

  // Schedule task completion check
  const scheduleCompletionCheck = useCallback((task) => {
    if (!task.scheduled_date || !task.scheduled_time || !task.duration) return;
    
    const taskDateTime = new Date(`${task.scheduled_date}T${task.scheduled_time}`);
    const endTime = addMinutes(taskDateTime, task.duration);
    const now = new Date();
    
    if (endTime > now) {
      const timeoutId = setTimeout(async () => {
        // Check if task is still not completed
        const updatedTask = await Task.get(task.id);
        if (!updatedTask.completed) {
          toast({
            title: "Task Due",
            description: `Did you complete "${task.title}"?`,
            duration: 0, // Won't auto-dismiss
            type: NOTIFICATION_TYPE.COMPLETION,
            action: "Mark Complete",
            onAction: async () => {
              await Task.update(task.id, { 
                completed: true,
                completed_at: new Date().toISOString()
              });
              
              // Update performance metrics
              if (isToday(parseISO(task.scheduled_date))) {
                const performance = await Performance.filter({ 
                  date: format(new Date(), "yyyy-MM-dd") 
                });
                
                if (performance.length > 0) {
                  const current = performance[0];
                  await Performance.update(current.id, {
                    tasks_completed: current.tasks_completed + 1,
                    productivity_score: Math.min(100, current.productivity_score + 5)
                  });
                }
              }
            }
          });
        }
      }, endTime.getTime() - now.getTime());

      return timeoutId;
    }
  }, []);

  // Schedule daily summary notification
  const scheduleDailySummary = useCallback(() => {
    if (!preferences?.notification_preferences?.daily_summary) return;
    
    // Schedule for end of day (6 PM)
    const now = new Date();
    const summaryTime = new Date(now);
    summaryTime.setHours(18, 0, 0, 0);
    
    if (summaryTime > now) {
      const timeoutId = setTimeout(async () => {
        const todaysTasks = tasks.filter(task => 
          task.scheduled_date === format(now, "yyyy-MM-dd")
        );
        
        const completed = todaysTasks.filter(t => t.completed).length;
        const total = todaysTasks.length;
        const completion = total > 0 ? Math.round((completed / total) * 100) : 0;
        
        toast({
          title: "Daily Summary",
          description: `You completed ${completed} out of ${total} tasks today (${completion}% completion rate)`,
          type: NOTIFICATION_TYPE.SUMMARY,
          duration: 0,
          action: "View Report"
        });
      }, summaryTime.getTime() - now.getTime());

      return timeoutId;
    }
  }, [preferences?.notification_preferences?.daily_summary, tasks]);

  // Schedule weekly performance insights
  const schedulePerformanceInsights = useCallback(() => {
    if (!preferences?.notification_preferences?.performance_insights) return;
    
    // Schedule for end of week (Friday 4 PM)
    const now = new Date();
    const insightTime = new Date(now);
    insightTime.setHours(16, 0, 0, 0);
    
    // If it's Friday and before 4 PM
    if (now.getDay() === 5 && insightTime > now) {
      const timeoutId = setTimeout(async () => {
        // Calculate weekly stats
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay() + 1);
        
        const weekTasks = tasks.filter(task => {
          const taskDate = parseISO(task.scheduled_date);
          return taskDate >= weekStart && taskDate <= now;
        });
        
        const completed = weekTasks.filter(t => t.completed).length;
        const total = weekTasks.length;
        const completion = total > 0 ? Math.round((completed / total) * 100) : 0;
        
        toast({
          title: "Weekly Performance Insights",
          description: `This week: ${completed}/${total} tasks completed (${completion}% completion rate)`,
          type: NOTIFICATION_TYPE.PERFORMANCE,
          duration: 0,
          action: "View Details"
        });
      }, insightTime.getTime() - now.getTime());

      return timeoutId;
    }
  }, [preferences?.notification_preferences?.performance_insights, tasks]);

  // Clean up notifications when component unmounts
  React.useEffect(() => {
    const timeoutIds = [];
    
    // Schedule notifications for upcoming tasks
    tasks.forEach(task => {
      if (task.completed) return;
      
      const reminderId = scheduleTaskReminder(task);
      if (reminderId) timeoutIds.push(reminderId);
      
      const completionId = scheduleCompletionCheck(task);
      if (completionId) timeoutIds.push(completionId);
    });
    
    // Schedule summary and insights
    const summaryId = scheduleDailySummary();
    if (summaryId) timeoutIds.push(summaryId);
    
    const insightsId = schedulePerformanceInsights();
    if (insightsId) timeoutIds.push(insightsId);
    
    // Cleanup function
    return () => {
      timeoutIds.forEach(id => clearTimeout(id));
    };
  }, [tasks, preferences]);

  return null; // This is a non-visual component
}