import React from "react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import TaskItem from "../task/TaskItem";

export default function HourlyTimeSlot({
  hour,
  date,
  tasks = [],
  onDropTask,
  onTaskAction,
  isCurrentHour = false,
  compactTasks = false
}) {
  const hourDate = new Date(date);
  hourDate.setHours(hour);
  hourDate.setMinutes(0);
  hourDate.setSeconds(0);
  
  const formattedHour = format(hourDate, "h a").toLowerCase();
  
  // Check if this time slot is in the past
  const now = new Date();
  const isInPast = hourDate < now;
  
  // Calculate if now is within this hour
  const isNow = isCurrentHour && 
    now.getHours() === hour &&
    now.getDate() === date.getDate() &&
    now.getMonth() === date.getMonth() &&
    now.getFullYear() === date.getFullYear();

  // Calculate task positioning and height
  const calculateTaskStyle = (task) => {
    const [taskHour, taskMinute] = task.scheduled_time.split(':').map(Number);
    
    // Only show tasks that start in this hour slot
    if (taskHour !== hour) return null;
    
    // Calculate position from top (based on minutes)
    const topPosition = (taskMinute / 60) * 100;
    
    // Calculate height based on duration (minimum 50px for visibility)
    const heightPercentage = (task.duration / 60) * 100;
    const heightPixels = Math.max(50, (heightPercentage / 100) * 100); // 100px is the minimum height of hour slot
    
    return {
      position: 'absolute',
      top: `${topPosition}%`,
      left: '4px',
      right: '4px',
      height: `${heightPixels}px`,
      zIndex: 5
    };
  };

  const handleDragOver = (e) => {
    if (isInPast) {
      e.preventDefault();
      return;
    }
    
    e.preventDefault();
    e.currentTarget.classList.add("bg-blue-50", "dark:bg-blue-900/20");
  };

  const handleDragLeave = (e) => {
    e.currentTarget.classList.remove("bg-blue-50", "dark:bg-blue-900/20");
  };

  const handleDrop = (e) => {
    e.preventDefault();
    
    if (isInPast) return;
    
    e.currentTarget.classList.remove("bg-blue-50", "dark:bg-blue-900/20");
    
    try {
      const taskData = JSON.parse(e.dataTransfer.getData("task"));
      const scheduledDate = format(date, "yyyy-MM-dd");
      
      // Calculate minutes based on drop position
      const rect = e.currentTarget.getBoundingClientRect();
      const relativeY = e.clientY - rect.top;
      const minutes = Math.floor((relativeY / rect.height) * 60);
      
      // Round to nearest 5 minutes
      const roundedMinutes = Math.round(minutes / 5) * 5;
      
      // If current hour and dropping in past minutes, schedule for next available minute
      if (isCurrentHour && now.getMinutes() >= roundedMinutes) {
        const nextMinute = Math.ceil((now.getMinutes() + 1) / 5) * 5;
        const scheduledTime = `${hour.toString().padStart(2, "0")}:${nextMinute.toString().padStart(2, "0")}`;
        onDropTask(taskData, scheduledDate, scheduledTime);
      } else {
        const scheduledTime = `${hour.toString().padStart(2, "0")}:${roundedMinutes.toString().padStart(2, "0")}`;
        onDropTask(taskData, scheduledDate, scheduledTime);
      }
    } catch (error) {
      console.error("Error dropping task:", error);
    }
  };

  return (
    <div
      className={cn(
        "group relative border-t border-gray-200 dark:border-gray-700 transition-colors",
        hour >= 9 && hour < 17 ? "bg-white dark:bg-gray-900" : "bg-gray-50 dark:bg-gray-800/50",
        (hour < 7 || hour >= 22) && "bg-gray-100 dark:bg-gray-800",
        isNow && "bg-blue-50 dark:bg-blue-900/10",
        isInPast && "opacity-50 cursor-not-allowed"
      )}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      style={{ height: '100px' }} // Fixed height for consistent sizing
    >
      <div className="sticky left-0 w-16 pr-2 flex items-start h-full z-10">
        <div className="text-xs font-medium text-gray-500 dark:text-gray-400 pt-2 text-right w-full">
          {formattedHour}
          {isInPast && (
            <span className="block text-[10px] text-red-500 dark:text-red-400">
              Past
            </span>
          )}
        </div>
      </div>
      
      {isNow && (
        <div 
          className="absolute left-0 right-0 h-0.5 bg-red-500 z-10" 
          style={{ 
            top: `${((now.getMinutes() / 60) * 100)}%` 
          }}
        />
      )}
      
      {/* 15-minute interval markers */}
      <div className="absolute inset-0 pointer-events-none">
        {[15, 30, 45].map((minute) => (
          <div 
            key={minute}
            className="absolute left-0 right-0 border-t border-gray-100 dark:border-gray-800/50" 
            style={{ top: `${(minute / 60) * 100}%` }}
          />
        ))}
      </div>

      <div className="relative ml-16 h-full">
        {tasks.map(task => {
          const style = calculateTaskStyle(task);
          if (!style) return null; // Don't render if task doesn't belong in this slot
          
          return (
            <div 
              key={task.id}
              style={style}
              className="absolute w-[calc(100%-8px)]"
            >
              <TaskItem
                task={task}
                onComplete={(task) => onTaskAction('complete', task)}
                onEdit={(task) => onTaskAction('edit', task)}
                onDelete={(id) => onTaskAction('delete', id)}
                onDuplicate={(task) => onTaskAction('duplicate', task)}
                compact={compactTasks}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}