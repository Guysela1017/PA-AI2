import React, { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function TimePickerDemo({
  className,
  value,
  onChange,
}) {
  const [hour, setHour] = useState(() => {
    if (value) {
      return value.split(":")[0];
    }
    return "09";
  });
  
  const [minute, setMinute] = useState(() => {
    if (value) {
      return value.split(":")[1];
    }
    return "00";
  });

  const handleHourChange = (e) => {
    const newHour = e.target.value.padStart(2, "0");
    setHour(newHour);
    if (onChange) {
      onChange(`${newHour}:${minute}`);
    }
  };

  const handleMinuteChange = (e) => {
    const newMinute = e.target.value.padStart(2, "0");
    setMinute(newMinute);
    if (onChange) {
      onChange(`${hour}:${newMinute}`);
    }
  };

  return (
    <div className={cn("flex space-x-2", className)}>
      <div className="grid gap-1 text-center">
        <Label htmlFor="hours" className="text-xs">
          Hours
        </Label>
        <Input
          id="hours"
          className="w-16 text-center"
          value={hour}
          onChange={handleHourChange}
          min={0}
          max={23}
          type="number"
        />
      </div>
      <div className="grid gap-1 text-center">
        <Label htmlFor="minutes" className="text-xs">
          Minutes
        </Label>
        <Input
          id="minutes"
          className="w-16 text-center"
          value={minute}
          onChange={handleMinuteChange}
          min={0}
          max={59}
          type="number"
        />
      </div>
    </div>
  );
}