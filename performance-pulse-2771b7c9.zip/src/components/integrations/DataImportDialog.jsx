import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { Loader2, Upload } from "lucide-react";

export default function DataImportDialog({ 
  isOpen, 
  onClose, 
  onImport,
  importType // 'fitness' or 'calendar'
}) {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleFileUpload = async (e) => {
    const uploadedFile = e.target.files[0];
    if (!uploadedFile) return;
    setFile(uploadedFile);
  };

  const handleImport = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    try {
      // First upload the file
      const { file_url } = await UploadFile({ file });

      // Extract data based on import type
      const schema = importType === 'fitness' ? {
        type: "object",
        properties: {
          date: { type: "string", format: "date" },
          activity_type: { type: "string" },
          duration: { type: "number" },
          calories: { type: "number" },
          heart_rate: { type: "number" },
          steps: { type: "number" }
        }
      } : {
        type: "object",
        properties: {
          title: { type: "string" },
          start_time: { type: "string" },
          end_time: { type: "string" },
          description: { type: "string" },
          location: { type: "string" }
        }
      };

      const result = await ExtractDataFromUploadedFile({
        file_url,
        json_schema: schema
      });

      if (result.status === "success") {
        onImport(result.output);
        onClose();
      } else {
        setError("Could not parse the file. Please check the format and try again.");
      }
    } catch (error) {
      setError("Error importing data. Please try again.");
      console.error("Import error:", error);
    }

    setLoading(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Import {importType === 'fitness' ? 'Fitness' : 'Calendar'} Data</DialogTitle>
          <DialogDescription>
            Upload a CSV file exported from your {importType === 'fitness' ? 'fitness tracker' : 'calendar'}.
            {importType === 'fitness' && (
              <div className="mt-2">
                <p className="text-sm text-muted-foreground">
                  Supported formats:
                  - WHOOP export (CSV)
                  - Apple Health export (XML)
                  - Google Fit export (CSV)
                </p>
              </div>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="grid w-full max-w-sm items-center gap-1.5">
            <Label htmlFor="file">File</Label>
            <Input 
              id="file" 
              type="file" 
              accept=".csv,.xml"
              onChange={handleFileUpload}
            />
          </div>

          {error && (
            <div className="text-sm text-red-500">
              {error}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleImport}
            disabled={!file || loading}
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Importing...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Import
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}