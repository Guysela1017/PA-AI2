import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from "recharts";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export default function PerformanceTrends({ 
  weekData = [], 
  className = "" 
}) {
  // Calculate trends
  const getTrend = (data) => {
    if (data.length < 2) return "stable";
    const firstValue = data[0].value;
    const lastValue = data[data.length - 1].value;
    const difference = lastValue - firstValue;
    
    if (difference > 5) return "up";
    if (difference < -5) return "down";
    return "stable";
  };

  // Render trend indicator
  const TrendIndicator = ({ trend, label }) => {
    const getColor = () => {
      switch (trend) {
        case "up": return "text-green-500";
        case "down": return "text-red-500";
        default: return "text-yellow-500";
      }
    };

    const Icon = trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;

    return (
      <div className="flex items-center gap-1">
        <Icon className={`h-4 w-4 ${getColor()}`} />
        <span className="text-sm text-gray-600 dark:text-gray-400">{label}</span>
      </div>
    );
  };

  // Generate health score based on various metrics
  const calculateHealthScore = (day) => {
    const weights = {
      energy_level: 0.4,
      focus_score: 0.3,
      productivity_score: 0.3
    };

    return Math.round(
      (day.energy_level * weights.energy_level * 10) +
      (day.focus_score * weights.focus_score * 10) +
      (day.productivity_score * weights.productivity_score)
    );
  };

  // Custom tooltip for the line chart
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <p className="font-medium">{label}</p>
          {payload.map((entry, index) => (
            <p 
              key={index} 
              className="text-sm"
              style={{ color: entry.color }}
            >
              {entry.name}: {entry.value}%
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className={className}>
      <Card>
        <CardHeader>
          <CardTitle>Weekly Performance Trends</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Performance Graph */}
          <div className="h-[300px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={weekData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={(date) => format(new Date(date), "EEE")}
                />
                <YAxis domain={[0, 100]} />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={70} stroke="#10B981" strokeDasharray="3 3" />
                <Line
                  type="monotone"
                  name="Productivity"
                  dataKey="productivity_score"
                  stroke="#3B82F6"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  name="Energy"
                  dataKey={(d) => d.energy_level * 10}
                  stroke="#F59E0B"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
                <Line
                  type="monotone"
                  name="Focus"
                  dataKey={(d) => d.focus_score * 10}
                  stroke="#8B5CF6"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
                <Line
                  type="monotone"
                  name="Health Score"
                  dataKey={(d) => calculateHealthScore(d)}
                  stroke="#10B981"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Category Trends */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Productivity
              </h4>
              <div className="flex items-center justify-between">
                <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400">
                  {Math.round(weekData.reduce((acc, day) => acc + day.productivity_score, 0) / weekData.length)}%
                </Badge>
                <TrendIndicator 
                  trend={getTrend(weekData.map(d => ({ value: d.productivity_score })))}
                  label="7-day"
                />
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Energy Level
              </h4>
              <div className="flex items-center justify-between">
                <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400">
                  {Math.round(weekData.reduce((acc, day) => acc + day.energy_level, 0) / weekData.length * 10)}%
                </Badge>
                <TrendIndicator 
                  trend={getTrend(weekData.map(d => ({ value: d.energy_level * 10 })))}
                  label="7-day"
                />
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Focus Score
              </h4>
              <div className="flex items-center justify-between">
                <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400">
                  {Math.round(weekData.reduce((acc, day) => acc + day.focus_score, 0) / weekData.length * 10)}%
                </Badge>
                <TrendIndicator 
                  trend={getTrend(weekData.map(d => ({ value: d.focus_score * 10 })))}
                  label="7-day"
                />
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                Health Score
              </h4>
              <div className="flex items-center justify-between">
                <Badge className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                  {Math.round(weekData.reduce((acc, day) => acc + calculateHealthScore(day), 0) / weekData.length)}%
                </Badge>
                <TrendIndicator 
                  trend={getTrend(weekData.map(d => ({ value: calculateHealthScore(d) })))}
                  label="7-day"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}