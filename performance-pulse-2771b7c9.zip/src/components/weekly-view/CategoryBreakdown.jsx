import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip
} from "recharts";

const CATEGORY_COLORS = {
  work: "#3B82F6",      // Blue
  personal: "#8B5CF6",  // Purple
  health: "#10B981",    // Green
  learning: "#F59E0B",  // Yellow
  other: "#6B7280"      // Gray
};

export default function CategoryBreakdown({ 
  tasks = [], 
  className = "" 
}) {
  // Calculate category distribution
  const categoryData = React.useMemo(() => {
    const distribution = tasks.reduce((acc, task) => {
      acc[task.category] = (acc[task.category] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(distribution).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1).replace(/_/g, ' '),
      value,
      color: CATEGORY_COLORS[name]
    }));
  }, [tasks]);

  // Calculate completion rates by category
  const categoryCompletion = React.useMemo(() => {
    const completion = tasks.reduce((acc, task) => {
      if (!acc[task.category]) {
        acc[task.category] = { total: 0, completed: 0 };
      }
      acc[task.category].total++;
      if (task.completed) {
        acc[task.category].completed++;
      }
      return acc;
    }, {});

    return Object.entries(completion).map(([category, stats]) => ({
      name: category.charAt(0).toUpperCase() + category.slice(1).replace(/_/g, ' '),
      rate: Math.round((stats.completed / stats.total) * 100),
      color: CATEGORY_COLORS[category]
    }));
  }, [tasks]);

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <p className="font-medium">{data.name}</p>
          <p className="text-sm" style={{ color: data.color }}>
            Tasks: {data.value}
          </p>
          <p className="text-sm" style={{ color: data.color }}>
            Completion: {categoryCompletion.find(c => c.name === data.name)?.rate || 0}%
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className={className}>
      <Card>
        <CardHeader>
          <CardTitle>Category Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Distribution Chart */}
            <div className="h-[300px]">
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-4">
                Task Distribution
              </h4>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    labelLine={false}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Completion Rates */}
            <div>
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-4">
                Completion Rates
              </h4>
              <div className="space-y-4">
                {categoryCompletion.map((category) => (
                  <div key={category.name} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">
                        {category.name}
                      </span>
                      <Badge 
                        variant="outline"
                        className="font-mono"
                        style={{ color: category.color, borderColor: category.color }}
                      >
                        {category.rate}%
                      </Badge>
                    </div>
                    <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full transition-all duration-500 rounded-full"
                        style={{ 
                          width: `${category.rate}%`,
                          backgroundColor: category.color 
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}