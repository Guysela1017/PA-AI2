
import React, { useState, useEffect } from "react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Clock,
  Calendar as CalendarIcon,
  Tag,
  AlertCircle,
  Zap,
  Repeat,
} from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";
import { Sparkles } from "lucide-react";

export default function TaskModal({ 
  isOpen, 
  onClose, 
  onSave, 
  initialTask = null,
  userPreferences = {}
}) {
  const defaultTask = {
    title: "",
    description: "",
    priority: "medium",
    category: "work",
    duration: 30,
    scheduled_date: format(new Date(), "yyyy-MM-dd"),
    scheduled_time: format(new Date(), "HH:mm"),
    completed: false,
    recurring: false,
    recurrence_pattern: "daily",
    energy_required: "medium",
    tags: [],
    auto_schedule: false
  };

  const [task, setTask] = useState(initialTask || defaultTask);
  const [tagInput, setTagInput] = useState("");

  useEffect(() => {
    if (initialTask) {
      setTask(initialTask);
    } else {
      setTask(defaultTask);
    }
  }, [isOpen, initialTask]);

  const handleChange = (field, value) => {
    setTask({ ...task, [field]: value });
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !task.tags.includes(tagInput.trim())) {
      setTask({
        ...task,
        tags: [...(task.tags || []), tagInput.trim()],
      });
      setTagInput("");
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setTask({
      ...task,
      tags: task.tags.filter((tag) => tag !== tagToRemove),
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(task);
  };

  const priorityColors = {
    low: "bg-blue-50 text-blue-700 border-blue-200",
    medium: "bg-yellow-50 text-yellow-700 border-yellow-200",
    high: "bg-orange-50 text-orange-700 border-orange-200",
    urgent: "bg-red-50 text-red-700 border-red-200",
  };

  const categoryIcons = {
    work: "💼",
    personal: "🏠",
    health: "💪",
    learning: "📚",
    other: "📌",
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-slate-50 p-6 fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg sm:max-w-[525px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">
            {initialTask ? "Edit Task" : "Create New Task"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              placeholder="Task title"
              value={task.title}
              onChange={(e) => handleChange("title", e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Task details"
              value={task.description}
              onChange={(e) => handleChange("description", e.target.value)}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <Select
                value={task.priority}
                onValueChange={(value) => handleChange("priority", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={task.category}
                onValueChange={(value) => handleChange("category", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="work">Work</SelectItem>
                  <SelectItem value="personal">Personal</SelectItem>
                  <SelectItem value="health">Health</SelectItem>
                  <SelectItem value="learning">Learning</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Input
                id="duration"
                type="number"
                min="5"
                step="5"
                value={task.duration}
                onChange={(e) => handleChange("duration", Number(e.target.value))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="energy">Energy Required</Label>
              <Select
                value={task.energy_required}
                onValueChange={(value) => handleChange("energy_required", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Energy level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low Energy</SelectItem>
                  <SelectItem value="medium">Medium Energy</SelectItem>
                  <SelectItem value="high">High Energy</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Scheduled Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !task.scheduled_date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {task.scheduled_date ? (
                      format(new Date(task.scheduled_date), "PPP")
                    ) : (
                      <span>Pick a date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={task.scheduled_date ? new Date(task.scheduled_date) : new Date()}
                    onSelect={(date) =>
                      handleChange("scheduled_date", format(date, "yyyy-MM-dd"))
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between mb-2">
                <Label htmlFor="scheduling-mode">Scheduling</Label>
                <div className="bg-slate-50 text-sky-600 m-0 p-2 flex items-center space-x-2 dark:bg-gray-800 rounded-full">
                  <button
                    type="button"
                    className={`text-xs px-3 py-1 rounded-full transition-colors ${!task.auto_schedule ? 
                      "bg-white dark:bg-gray-700 shadow" : 
                      "text-gray-500 dark:text-gray-400"}`}
                    onClick={() => handleChange("auto_schedule", false)}
                  >
                    Manual
                  </button>
                  <button
                    type="button"
                    className={`text-xs px-3 py-1 rounded-full transition-colors ${task.auto_schedule ? 
                      "bg-white dark:bg-gray-700 shadow" : 
                      "text-gray-500 dark:text-gray-400"}`}
                    onClick={() => handleChange("auto_schedule", true)}
                  >
                    <Sparkles className="inline-block w-3 h-3 mr-1" />
                    Auto
                  </button>
                </div>
              </div>
              
              {task.auto_schedule ? (
                <div className="flex items-center px-3 py-2 border border-dashed border-indigo-300 dark:border-indigo-700 rounded-md bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300">
                  <Sparkles className="h-4 w-4 text-indigo-500 mr-2" />
                  <span className="text-sm">AI will find the optimal time</span>
                </div>
              ) : (
                <div className="relative">
                  <Clock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="time"
                    type="time"
                    value={task.scheduled_time}
                    onChange={(e) => handleChange("scheduled_time", e.target.value)}
                    className="pl-10"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="recurring"
                checked={task.recurring}
                onCheckedChange={(checked) =>
                  handleChange("recurring", checked)
                }
              />
              <Label htmlFor="recurring" className="flex items-center">
                <Repeat className="mr-2 h-4 w-4" />
                Recurring Task
              </Label>
            </div>

            {task.recurring && (
              <div className="ml-6 mt-2">
                <Select
                  value={task.recurrence_pattern}
                  onValueChange={(value) =>
                    handleChange("recurrence_pattern", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Recurrence pattern" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekdays">Weekdays</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags</Label>
            <div className="flex space-x-2">
              <Input
                id="tags"
                placeholder="Add a tag"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
              />
              <Button type="button" onClick={handleAddTag} variant="outline">
                Add
              </Button>
            </div>
            {task.tags && task.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {task.tags.map((tag) => (
                  <div
                    key={tag}
                    className="flex items-center bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 px-3 py-1 rounded-full text-sm"
                  >
                    <Tag className="h-3 w-3 mr-1" />
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                    >
                      &times;
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 ml-2">
              Save Task
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
