import React from "react";
import { format } from "date-fns";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Clock, Tag, Edit2, Copy, Trash2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

export default function TaskItem({
  task,
  onComplete,
  onEdit,
  onDelete,
  onDuplicate,
  compact = false,
}) {
  const priorityColors = {
    low: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800",
    medium: "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-800",
    high: "bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-800",
    urgent: "bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800",
  };

  const categoryIcons = {
    work: "💼",
    personal: "🏠",
    health: "💪",
    learning: "📚",
    other: "📌",
  };

  const energyIcons = {
    low: "🔋",
    medium: "🔋🔋",
    high: "🔋🔋🔋",
  };

  const formatDuration = (minutes) => {
    if (minutes < 60) {
      return `${minutes}m`;
    }
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes
      ? `${hours}h ${remainingMinutes}m`
      : `${hours}h`;
  };

  return (
    <Card
      className={cn(
        "group relative overflow-hidden transition-all hover:shadow-md dark:border-gray-800",
        compact ? "p-3" : "p-4",
        task.completed && "opacity-60"
      )}
    >
      <div className={`flex ${compact ? "items-start" : "items-center"}`}>
        <div className="mr-3 flex-shrink-0">
          <Checkbox
            checked={task.completed}
            onCheckedChange={() => onComplete(task)}
            className="mt-1"
          />
        </div>

        <div className="flex-grow min-w-0">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
            <div className="flex-grow">
              <h3
                className={cn(
                  "text-base font-medium line-clamp-1",
                  task.completed && "line-through text-gray-500 dark:text-gray-400"
                )}
              >
                {task.title}
              </h3>
              {!compact && task.description && (
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                  {task.description}
                </p>
              )}
            </div>

            <div className="flex items-center mt-1 sm:mt-0 sm:ml-4">
              <div className="flex items-center mr-2">
                <Clock className="h-3 w-3 text-gray-400 mr-1" />
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {formatDuration(task.duration)}
                </span>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                      className="w-5 h-5"
                    >
                      <path d="M3 10a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM8.5 10a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM15.5 8.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3z" />
                    </svg>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit(task)}>
                    <Edit2 className="h-4 w-4 mr-2" />
                    Edit
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDuplicate(task)}>
                    <Copy className="h-4 w-4 mr-2" />
                    Duplicate
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete(task.id)}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          <div className="mt-2 flex flex-wrap gap-2">
            <Badge
              variant="outline"
              className={cn("border text-xs", priorityColors[task.priority])}
            >
              {task.priority}
            </Badge>

            <Badge
              variant="outline"
              className="text-xs bg-gray-50 border-gray-200 text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300"
            >
              {categoryIcons[task.category]} {task.category}
            </Badge>

            {!compact && task.energy_required && (
              <Badge
                variant="outline"
                className="text-xs bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800"
              >
                {energyIcons[task.energy_required]} energy
              </Badge>
            )}

            {task.recurring && (
              <Badge
                variant="outline"
                className="text-xs bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800"
              >
                Recurring: {task.recurrence_pattern}
              </Badge>
            )}
          </div>

          {!compact && task.tags && task.tags.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {task.tags.map((tag) => (
                <div
                  key={tag}
                  className="inline-flex items-center text-xs bg-gray-100 text-gray-800 px-2 py-0.5 rounded-full dark:bg-gray-800 dark:text-gray-200"
                >
                  <Tag className="h-2 w-2 mr-1" />
                  {tag}
                </div>
              ))}
            </div>
          )}

          <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
            {task.scheduled_date && task.scheduled_time && (
              <div className="flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                <span>
                  {format(new Date(task.scheduled_date), "MMM d")} at{" "}
                  {task.scheduled_time}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}