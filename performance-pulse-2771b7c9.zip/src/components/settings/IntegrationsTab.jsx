import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import DataImportDialog from ".@/api/integrations/DataImportDialog";
import {
  Activity,
  Calendar,
  Upload,
  Download,
  AlertCircle
} from "lucide-react";

export default function IntegrationsTab() {
  const [importDialog, setImportDialog] = useState({ open: false, type: null });

  const handleImportData = (data) => {
    // Process imported data
    console.log('Imported data:', data);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Fitness Data</CardTitle>
          <CardDescription>
            Import your fitness data from various tracking devices
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-purple-100 dark:bg-purple-900/20 rounded-lg">
                <Activity className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h3 className="font-medium">WHOOP Data</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Import your WHOOP activity and recovery data
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Manual Import</Badge>
              <Button
                variant="outline"
                onClick={() => setImportDialog({ open: true, type: 'fitness' })}
              >
                <Upload className="h-4 w-4 mr-2" />
                Import
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-lg">
                <Activity className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <h3 className="font-medium">Apple Health</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Import your Apple Health data export
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Manual Import</Badge>
              <Button
                variant="outline"
                onClick={() => setImportDialog({ open: true, type: 'fitness' })}
              >
                <Upload className="h-4 w-4 mr-2" />
                Import
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Calendar Integration</CardTitle>
          <CardDescription>
            Import and export calendar events
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                <Calendar className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="font-medium">Calendar Events</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Import/Export calendar events (iCal format)
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Manual Sync</Badge>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setImportDialog({ open: true, type: 'calendar' })}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Import
                </Button>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 mt-0.5" />
              <div>
                <h4 className="font-medium text-yellow-800 dark:text-yellow-300">
                  Direct Calendar Integration Coming Soon
                </h4>
                <p className="text-sm text-yellow-700 dark:text-yellow-400 mt-1">
                  We're working on direct integration with Google Calendar and Apple Calendar. 
                  For now, you can import and export calendar data manually using the iCal format.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <DataImportDialog
        isOpen={importDialog.open}
        onClose={() => setImportDialog({ open: false, type: null })}
        onImport={handleImportData}
        importType={importDialog.type}
      />
    </div>
  );
}