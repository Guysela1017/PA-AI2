
import React from "react";
import { format } from "date-fns";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import {
  CheckCircle,
  Clock,
  Star,
  Zap,
  Brain,
  XCircle,
  Plus
} from "lucide-react";

export default function DayDetails({
  isOpen,
  onClose,
  date,
  tasks = [],
  performance,
  onAddTask,
  onTaskAction
}) {
  // Calculate metrics
  const completedTasks = tasks.filter(t => t.completed).length;
  const missedTasks = tasks.filter(t => t.status === 'missed').length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  // Group tasks by time periods
  const getTasksByPeriod = () => {
    const periods = {
      morning: [],
      afternoon: [],
      evening: []
    };

    tasks.forEach(task => {
      if (!task.scheduled_time) {
        periods.morning.push(task);
        return;
      }

      const hour = parseInt(task.scheduled_time.split(':')[0]);
      if (hour < 12) {
        periods.morning.push(task);
      } else if (hour < 17) {
        periods.afternoon.push(task);
      } else {
        periods.evening.push(task);
      }
    });

    return periods;
  };

  const tasksByPeriod = getTasksByPeriod();

  const getTaskStatus = (task) => {
    if (task.completed) {
      return {
        icon: CheckCircle,
        color: "text-green-500",
        text: "Completed"
      };
    }
    if (task.status === 'missed') {
      return {
        icon: XCircle,
        color: "text-red-500",
        text: "Missed"
      };
    }
    return {
      icon: Clock,
      color: "text-blue-500",
      text: "Pending"
    };
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader className="mb-6">
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center gap-2">
              <span>{format(date, "EEEE, MMMM d, yyyy")}</span>
              {performance?.productivity_score >= 85 && (
                <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
              )}
            </SheetTitle>
            <Button
              size="sm"
              onClick={() => onAddTask(date)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Task
            </Button>
          </div>
        </SheetHeader>

        {/* Performance Overview */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {performance?.productivity_score || 0}%
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Productivity
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                  {performance?.energy_level || 0}/10
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Energy
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                  {performance?.focus_score || 0}/10
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Focus
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {completedTasks}/{totalTasks}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Tasks Done
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tasks by Time Period */}
        <div className="space-y-6">
          {/* Morning Tasks */}
          <div>
            <h3 className="flex items-center text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">
              <span className="bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 p-1 rounded mr-2">
                ☀️
              </span>
              Morning
            </h3>
            {tasksByPeriod.morning.length > 0 ? (
              <div className="space-y-2">
                {tasksByPeriod.morning.map(task => {
                  const status = getTaskStatus(task);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div
                      key={task.id}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`flex-shrink-0 ${status.color}`}>
                            <StatusIcon className="h-4 w-4" />
                          </span>
                          <p className={cn(
                            "text-sm font-medium truncate",
                            task.completed && "line-through text-gray-500"
                          )}>
                            {task.title}
                          </p>
                        </div>
                        {task.scheduled_time && (
                          <p className="text-xs text-gray-500 mt-1">
                            {format(new Date(`2000-01-01T${task.scheduled_time}`), "h:mm a")}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            task.priority === "urgent" && "bg-red-50 text-red-700 border-red-200",
                            task.priority === "high" && "bg-orange-50 text-orange-700 border-orange-200"
                          )}
                        >
                          {task.priority}
                        </Badge>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-500 hover:text-gray-700"
                          onClick={() => onTaskAction("toggle", task)}
                        >
                          {task.completed ? "Undo" : "Complete"}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">
                No morning tasks scheduled
              </p>
            )}
          </div>

          {/* Afternoon Tasks */}
          <div>
            <h3 className="flex items-center text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">
              <span className="bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200 p-1 rounded mr-2">
                🌤️
              </span>
              Afternoon
            </h3>
            {/* Same pattern as morning tasks */}
            {tasksByPeriod.afternoon.length > 0 ? (
              <div className="space-y-2">
                {tasksByPeriod.afternoon.map(task => {
                  const status = getTaskStatus(task);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div
                      key={task.id}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    >
                      {/* Same structure as morning task item */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`flex-shrink-0 ${status.color}`}>
                            <StatusIcon className="h-4 w-4" />
                          </span>
                          <p className={cn(
                            "text-sm font-medium truncate",
                            task.completed && "line-through text-gray-500"
                          )}>
                            {task.title}
                          </p>
                        </div>
                        {task.scheduled_time && (
                          <p className="text-xs text-gray-500 mt-1">
                            {format(new Date(`2000-01-01T${task.scheduled_time}`), "h:mm a")}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            task.priority === "urgent" && "bg-red-50 text-red-700 border-red-200",
                            task.priority === "high" && "bg-orange-50 text-orange-700 border-orange-200"
                          )}
                        >
                          {task.priority}
                        </Badge>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-500 hover:text-gray-700"
                          onClick={() => onTaskAction("toggle", task)}
                        >
                          {task.completed ? "Undo" : "Complete"}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">
                No afternoon tasks scheduled
              </p>
            )}
          </div>

          {/* Evening Tasks */}
          <div>
            <h3 className="flex items-center text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">
              <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-200 p-1 rounded mr-2">
                🌙
              </span>
              Evening
            </h3>
            {/* Same pattern as morning tasks */}
            {tasksByPeriod.evening.length > 0 ? (
              <div className="space-y-2">
                {tasksByPeriod.evening.map(task => {
                  const status = getTaskStatus(task);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div
                      key={task.id}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    >
                      {/* Same structure as morning task item */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`flex-shrink-0 ${status.color}`}>
                            <StatusIcon className="h-4 w-4" />
                          </span>
                          <p className={cn(
                            "text-sm font-medium truncate",
                            task.completed && "line-through text-gray-500"
                          )}>
                            {task.title}
                          </p>
                        </div>
                        {task.scheduled_time && (
                          <p className="text-xs text-gray-500 mt-1">
                            {format(new Date(`2000-01-01T${task.scheduled_time}`), "h:mm a")}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            task.priority === "urgent" && "bg-red-50 text-red-700 border-red-200",
                            task.priority === "high" && "bg-orange-50 text-orange-700 border-orange-200"
                          )}
                        >
                          {task.priority}
                        </Badge>
                        
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-500 hover:text-gray-700"
                          onClick={() => onTaskAction("toggle", task)}
                        >
                          {task.completed ? "Undo" : "Complete"}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">
                No evening tasks scheduled
              </p>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
