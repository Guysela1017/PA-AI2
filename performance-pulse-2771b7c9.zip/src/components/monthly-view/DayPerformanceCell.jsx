import React from "react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Star, CheckCircle, XCircle, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function DayPerformanceCell({
  date,
  isToday,
  isCurrentMonth,
  tasks = [],
  performance,
  onClick,
}) {
  // Calculate performance metrics
  const completedTasks = tasks.filter(t => t.completed).length;
  const missedTasks = tasks.filter(t => t.status === 'missed').length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  
  // Get cell background color based on performance
  const getCellStyle = () => {
    if (!isCurrentMonth) return "opacity-40";
    if (!totalTasks) return "";
    
    if (performance?.productivity_score >= 85) {
      return "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800";
    }
    if (completionRate >= 60) {
      return "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800";
    }
    if (missedTasks > 0) {
      return "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800";
    }
    if (completionRate > 0) {
      return "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800";
    }
    return "";
  };

  return (
    <div
      className={cn(
        "h-28 sm:h-36 p-1 border overflow-hidden transition-colors cursor-pointer hover:shadow-md",
        isToday && "border-blue-500 dark:border-blue-400",
        getCellStyle()
      )}
      onClick={onClick}
    >
      <div className="flex justify-between items-start">
        <span
          className={cn(
            "text-sm font-semibold inline-flex items-center justify-center rounded-full w-6 h-6",
            isToday
              ? "bg-blue-500 text-white dark:bg-blue-600"
              : "text-gray-700 dark:text-gray-300"
          )}
        >
          {format(date, "d")}
        </span>

        {/* Performance indicators */}
        {totalTasks > 0 && (
          <div className="flex flex-col items-end gap-1">
            {performance?.productivity_score >= 85 && (
              <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
            )}
            <Badge
              variant="outline"
              className={cn(
                "text-xs",
                performance?.productivity_score >= 85 && "bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400",
                performance?.productivity_score >= 60 && performance?.productivity_score < 85 && "bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400",
                performance?.productivity_score < 60 && "bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400"
              )}
            >
              {performance?.productivity_score || 0}%
            </Badge>
          </div>
        )}
      </div>

      {/* Task summary */}
      {totalTasks > 0 && (
        <div className="mt-2 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <span className="flex items-center">
              <CheckCircle className="h-3 w-3 mr-1" />
              {completedTasks}/{totalTasks}
            </span>
            {missedTasks > 0 && (
              <span className="flex items-center text-red-500 dark:text-red-400">
                <XCircle className="h-3 w-3 mr-1" />
                {missedTasks}
              </span>
            )}
          </div>
          
          <Progress 
            value={completionRate}
            className="h-1"
            indicatorClassName={cn(
              completionRate >= 85 && "bg-green-500",
              completionRate >= 60 && completionRate < 85 && "bg-blue-500",
              completionRate < 60 && "bg-red-500"
            )}
          />
        </div>
      )}

      {/* Task preview */}
      <div className="mt-1 space-y-1">
        {tasks.slice(0, 2).map(task => (
          <div
            key={task.id}
            className={cn(
              "text-xs truncate px-1 py-0.5 rounded",
              task.completed
                ? "line-through text-gray-400 dark:text-gray-500"
                : task.priority === "urgent"
                  ? "bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-300"
                  : task.priority === "high"
                    ? "bg-orange-50 dark:bg-orange-900/20 text-orange-800 dark:text-orange-300"
                    : "bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-300"
            )}
          >
            {task.title}
          </div>
        ))}
        {tasks.length > 2 && (
          <div className="text-xs text-center text-gray-500 dark:text-gray-400">
            +{tasks.length - 2} more
          </div>
        )}
      </div>
    </div>
  );
}