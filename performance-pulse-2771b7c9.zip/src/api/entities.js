import { base44 } from './base44Client';


export const Task = base44.entities.Task;

export const Performance = base44.entities.Performance;



// auth sdk:
export const User = base44.auth;